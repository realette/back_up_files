/* global Link: true */
var Link = Link || {};
/* global Link: false */

Link.namespace = function (namespaceString) {
  'use strict';
  var parts = namespaceString.split('.')
    , parent = Link
    , i;

  if (parts[0] === "Link") {
    parts = parts.slice(1);
  }

  for (i = 0; i < parts.length; i += 1) {
    if (typeof parent[parts[i]] === "undefined") {
      parent[parts[i]] = {};
    }
    parent = parent[parts[i]];
  }

  return parent;
};

Link.namespace('Link.Product');

Link.Product = (function() {
  'use strict';

  var constructor
    , progressTextMap = {
      initializing: "Initializing",
      downloading: "Downloading",
      installing: "Installing",
      uninstalling: "Uninstalling"
    };

  constructor = function(def) {
    if (!(this instanceof Link.Product)) {
      return new Link.Product(def);
    }

    this.initializeProductFromDefinition(def);
    this.viewData = {};
  };

  constructor.prototype = {
    constructor: Link.Product
  };

  constructor.prototype.updateFromDefinition = function(def) {
    var wasInstalling = this.isInstalling;

    this.viewData.formerOrderScore = this.orderScore;
    this.initializeProductFromDefinition(def);
    this.viewData.justFinishedInstalling = (wasInstalling && !this.isInstalling);
  };

  constructor.prototype.initializeProductFromDefinition = function(def) {
    this.product = {
      code: def.code,
      title: def.title,
      version: def.version,
      productGroup: def.productGroup || "",

      license: def.license,
      installationState: def.installationState,
      updateState: def.updateState,

      licenseInfo: {
        expired: def.licenseInfo.expired || (def.licenseInfo.trialDaysLeft <= 0) || false,
        trialDaysLeft: def.licenseInfo.trialDaysLeft || 0,
        buyURI: def.licenseInfo.buyURI || "",
        upgradeURI: def.licenseInfo.upgradeURI || "",
        upgradeInfoURI: def.licenseInfo.upgradeInfoURI || "",
        indefiniteTrial: def.licenseInfo.trialType === "indefinite",
        planType: def.licenseInfo.planType || '',
        licenseEndDate: Link.Utils.parseDate(def.licenseInfo.licenseEnds),
        meta: def.licenseInfo.meta || {}
      },

      updateInfo: {
        updateURI: def.updateInfo.updateURI || "",
        whatsNew: def.updateInfo.whatsNew || ""
      },

      installationInfo: {
        installURI: def.installationInfo.installURI || "",
        uninstallURI: def.installationInfo.uninstallURI || "",
        cancelURI: def.installationInfo.cancelURI || "",
        progress: (typeof def.installationInfo.progress === 'number') ? def.installationInfo.progress : -1
      },

      hostApps: def.hostApps
    };

    if (def.installationInfo.progress === 'indeterminate') {
      this.product.installationInfo.progress = 'indeterminate';
    }

    // Special cases
    if (this.licenseMeta["limited"] && this.code === 110) {
      this.product.license = "limited";
      this.product.version += " Express";
      this.product.licenseInfo.upgradeURI = "rg://buy_sku?SHO-PLURALEYES-UD";
      this.product.licenseInfo.upgradeInfoURI = "rg://product_page?110&upgrade";
      this.product.licenseInfo.alternateHoverTitle = "Express Edition";
      this.product.licenseInfo.alternateHoverBody = "Thank you for using the express edition of this product. " +
                                                "To unlock all of its features please upgrade to the full version.";
    }
  };

  function defineGetter(thing, key, getter) {
    Object.defineProperty(thing.prototype, key, {get: getter});
  }

  defineGetter(constructor, "alternateHoverTitle", function() {
    return this.product.licenseInfo.alternateHoverTitle;
  });

  defineGetter(constructor, "alternateHoverBody", function() {
    return this.product.licenseInfo.alternateHoverBody;
  });

  defineGetter(constructor, "licenseMeta", function() {
    return this.product.licenseInfo.meta;
  });

  defineGetter(constructor, "code", function() {
    return this.product.code;
  });

  defineGetter(constructor, "title", function() {
    return this.product.title;
  });

  defineGetter(constructor, "version", function() {
    return this.product.version;
  });

  defineGetter(constructor, "isUpToDate", function() {
    return this.product.updateState === 'up-to-date';
  });

  defineGetter(constructor, "whatsNew", function() {
    return this.product.updateInfo.whatsNew;
  });

  defineGetter(constructor, "isUninstalling", function() {
    return this.product.installationState === 'uninstalling';
  });

  defineGetter(constructor, "notOnDiskAtAll", function() {
    return this.product.installationState === "not-installed";
  });

  defineGetter(constructor, "isInstalling", function() {
    return  this.product.installationState !== 'not-installed' &&
            this.product.installationState !== 'uninstalling' &&
            this.product.installationState !== 'installed';
  });

  defineGetter(constructor, "isInstalled", function() {
    return this.product.installationState === 'installed' ||
       (this.product.installationState !== 'installed' &&
        this.product.installationState !== 'not-installed' &&
        this.product.updateState === 'available');
  });

  defineGetter(constructor, "isTrial", function() {
    return this.product.license === 'trial';
  });

  defineGetter(constructor, "trialDaysLeft", function() {
    return this.product.licenseInfo.trialDaysLeft;
  });

  defineGetter(constructor, "licenseEndDate", function() {
    return this.product.licenseInfo.licenseEndDate;
  });

  defineGetter(constructor, "hasTrialExpired", function() {
    return  this.isTrial &&
            this.product.licenseInfo.trialDaysLeft <= 0 &&
            (this.isUniverse || !this.product.licenseInfo.indefiniteTrial);
  });

  defineGetter(constructor, "isIndefiniteTrial", function() {
    return this.product.licenseInfo.indefiniteTrial;
  });

  defineGetter(constructor, "isBeta", function() {
    return false;
  });

  defineGetter(constructor, "isUniverse", function() {
    return this.product.productGroup === 'universe';
  });

  defineGetter(constructor, "license", function() {
    return this.product.license;
  });

  defineGetter(constructor, "installURI", function() {
    return this.product.installationInfo.installURI;
  });

  defineGetter(constructor, "uninstallURI", function() {
    return this.product.installationInfo.uninstallURI;
  });

  defineGetter(constructor, "updateState", function() {
    return this.product.updateState;
  });

  defineGetter(constructor, "progress", function() {
    return this.product.installationInfo.progress;
  });

  defineGetter(constructor, "isIndeterminateProgress", function() {
    return (this.product.installationInfo.progress === 'indeterminate');
  });

  defineGetter(constructor, "progressText", function() {
    return progressTextMap[this.product.installationState] || "";
  });

  defineGetter(constructor, "updateURI", function() {
    return this.product.updateInfo.updateURI;
  });

  defineGetter(constructor, "buyURI", function() {
    return this.product.licenseInfo.buyURI;
  });

  defineGetter(constructor, "upgradeURI", function() {
    return this.product.licenseInfo.upgradeURI;
  });

  defineGetter(constructor, "upgradeInfoURI", function() {
    return this.product.licenseInfo.upgradeInfoURI;
  });

  defineGetter(constructor, "cancelURI", function() {
    return this.product.installationInfo.cancelURI;
  });

  defineGetter(constructor, "hostAppsInstalled", function() {
    return this.product.hostApps.filter(function(x) { return x.installed; });
  });

  defineGetter(constructor, "hostAppsNotInstalled", function() {
    return this.product.hostApps.filter(function(x) { return !x.installed; });
  });

  defineGetter(constructor, "orderScore", function () {
    var score = 0
      , upToDateLayer = 0
      , buyMeLayer = 500
      , upgradeMeLayer = 510
      , updateMeLayer = 1000;

    if (this.isUpToDate && !this.viewData.justFinishedInstalling) {
      // The things that are up-to-date go right to the bottom
      score = upToDateLayer;

      // Among the up-to-date things, the expired / indefinite trials should go
      // higher on the list (they'll have a buy button). Also Universe trials.
      if (this.isTrial) {
        score = buyMeLayer;
        if (this.trialDaysLeft > 0) {
          score += 1;
        }
      }

      // Free tools with upgrades go to their spot
      if (this.upgradeURI) {
        score = upgradeMeLayer;
      }

    } else {
      // The things that need updates float to the top
      score = updateMeLayer;

      // If something has an update, but you couldn't use it because
      // it is an expired trial, then don't include it with the
      // updates. It has a buy button, so put it with the buy stuff.
      if (this.hasTrialExpired && this.isTrial) {
        score = buyMeLayer;
      }
    }

    // Universe is at the top of whatever heap it finds itself.
    // This step is big enough to bump it above 'upgrade mes'.
    if (this.isUniverse) {

      // If it is mid-update, then leave it in the updateme layer
      // or else it will pop down.
      if (this.isUpToDate && this.isInstalling) {
        score = updateMeLayer;
      }
      score += 50;
    }

    return score;
  });

  return constructor;
}());

Link.namespace('Link.Utils');

Link.Utils = (function() {
	'use strict';
	
	function parseDate(dateString) {
    var splitDate, date;
    if (!dateString) {
      return 0;
    }
    splitDate = dateString.split('-');
    date = new Date(splitDate[1] + "/" + splitDate[2] + "/" + splitDate[0]);
    return date.getTime();
  }

  return {
    parseDate: parseDate
  };

})();

(function() {
  'use strict';

  var link = Link.App = angular.module('linkApp', ['ngRoute', 'ui.bootstrap']);

  link.config(['$routeProvider', '$locationProvider', '$compileProvider', '$sceProvider',
    function($routeProvider, $locationProvider, $compileProvider, $sceProvider) {
      $routeProvider.when('/', {
        redirectTo: '/products'
      });

      $routeProvider.when('/products', {
        templateUrl: '/partials/_products.html',
        controller: 'ProductController'
      });

      $routeProvider.when('/universe', {
        templateUrl: '/partials/_universe.html',
        controller: 'ProductController'
      });

      $routeProvider.when('/account', {
        templateUrl: '/partials/_universe.html',
        controller: 'ProductController'
      });

      $sceProvider.enabled(false);

      $compileProvider.aHrefSanitizationWhitelist(/^\s*(file|https?|rg):/);
    }]);

})();

(function() {
  'use strict';

  Link.App.controller('AppController',
    ['$scope', 'ProductSource', '$modal', '$location', '$window', 'CurrentUser', 'EventSource', 'Dialogues',
    function($scope, ProductSource, $modal, $location, $window, CurrentUser, EventSource, Dialogues) {

      $scope.InChunkOfSet = function(targetChunk, totalChunks, index, cardinality) {
        var low = Math.floor(cardinality * ((targetChunk - 1) / totalChunks) )
          , high = Math.floor(cardinality * (targetChunk / totalChunks));

        return (index >= low) && (index < high);
      };

      $scope.appReady = false;
      $scope.offlineMode = {active: false};
      $scope.httpProxyServer = '';
      $scope.httpsProxyServer = '';
      $scope.httpProxyUser = '';
      $scope.httpsProxyUser = '';
      $scope.httpProxyPassword = '';
      $scope.httpsProxyPassword = '';
      $scope.refreshThrobberText = "Updating Account Information";
      $scope.linkName = "Link";
      $scope.linkVersion = "1.8";
      $scope.os = "?";

      $scope.dialogue = {
        dialogueRevealed: false
      };

      $scope.$on('$routeChangeSuccess', function(scope, next, current){
        if (next.redirectTo || !current || current.redirectTo) {
          return;
        }

        if (next.loadedTemplateUrl.indexOf('products') > -1) {
          $window.location.href = "rg://current_perspective?Products";
        } else if (next.loadedTemplateUrl.indexOf('universe') > -1) {
          $window.location.href = "rg://current_perspective?Universe";
        }
      });

      $scope.altKeyPressed = false;

      $scope.distanceToBottom = function(target) {
        var distance = ($window.innerHeight - target.getBoundingClientRect().bottom);
        return distance;
      };

      $scope.keyEventHandler = function(event) {
        if (event.keyIdentifier === "Alt") {
          if (event.type === "keyup") {
            $scope.altKeyPressed = false;
          } else if (event.type === "keydown") {
            $scope.altKeyPressed = true;
          }
        }
      };

      EventSource.subscribe(function(event) {
        switch(event.type) {
        case('update_throbber'):
          $scope.refreshThrobberText = event.payload.text;
          return true;
        case('offline_mode'):
          $scope.offlineMode = {
            active: event.payload.active,
            forced: event.payload.forced,
            blurb: event.payload.blurb
          };
          return true;
        case('show_sign_in'):
          $scope.showLogin(false, false);
          return true;
        case('show_universe_sign_in'):
          $scope.showLogin(true, false);
          return true;
        case('show_preferences'):
          $modal.open({
            templateUrl: '/partials/_preferences_modal.html',
            scope: $scope,
            controller: 'PreferencesModalController',
            windowClass: 'dialogue',
            backdrop: 'static',
            keyboard: false
          });
          return true;
        case('show_about_box'):
          $scope.showAbout();
          return true;
        case('app_info'):
          $scope.linkName = event.payload.name;
          $scope.linkVersion = event.payload.version;
          $scope.urlRoot = event.payload.url_root;
          $scope.httpProxyServer = event.payload.httpProxyServer || '';
          $scope.httpsProxyServer = event.payload.httpsProxyServer || '';
          $scope.httpProxyUser = event.payload.httpProxyUser || '';
          $scope.httpsProxyUser = event.payload.httpsProxyUser || '';
          $scope.httpProxyPassword = event.payload.httpProxyPassword || '';
          $scope.httpsProxyPassword = event.payload.httpsProxyPassword || '';
          $scope.usePerspective(event.payload.perspective);
          $scope.os = event.payload.os;
          return true;
        case('perspective'):
          $scope.usePerspective(event.payload.perspective);
          return true;
        }
        return false;
      });

      $scope.usePerspective = function(perspective) {
        if (perspective === 'Universe') {
          $scope.go('/universe');
        } else if (perspective === 'Products') {
          $scope.go('/products');
        }
      };

      $scope.$watch(
        function() {
          return Dialogues.dialogueQueue;
        },
        function() {
          $scope.displayDialogue();
        }, true);

      $scope.$watch(
        function() {
          return EventSource.inLinkApp;
        },
        function() {
          $scope.debugMode = !EventSource.inLinkApp;
        });

      $scope.$watch(
        function() {
          return CurrentUser.getUpdateFrequency();
        },
        function() {
          $scope.updateFrequency = CurrentUser.getUpdateFrequency();
        }
      );

      $scope.$watch(
        function() {
          return CurrentUser.getAvailableHosts();
        },
        function() {
          $scope.isFCPXInstalled = !!(CurrentUser.getAvailableHosts().FCPX);
        }
      );

      $scope.$watch(
        function() {
          return CurrentUser.isLoggedIn();
        },
        function() {
          $scope.loggedIn = CurrentUser.isLoggedIn();
        }
      );

      $scope.$watch(
        function() {
          return CurrentUser.getEmailAddress();
        },
        function() {
          $scope.currentUserEmailAddress = CurrentUser.getEmailAddress();
        }
      );

      $scope.$watch(
        function() {
          return ProductSource.state;
        },
        function() {
          $scope.appReady = (ProductSource.state !== 'initial');
        }
     );
     
     $scope.$watch(
        function() {
          return CurrentUser.isRoamingEnabled();
        },
        function() {
          $scope.roamingEnabled = CurrentUser.isRoamingEnabled();
        }
     );

      $scope.refreshAccountInfo = function() {
        $scope.refreshThrobberText = "Refreshing Account Information";
        $window.location.href = "rg://refresh";
      };

      $scope.checkForUpdates = function() {
        $scope.refreshThrobberText = "Checking For Updates";
        $window.location.href = "rg://refresh";
      };

      $scope.escapeOfflineMode = function() {
        $scope.offlineMode = {active: false};
        $scope.refreshThrobberText = "Checking For Updates";
        $window.location.href = "rg://refresh";
      };

      $scope.init = function() {
      };

      $scope.visitMothership = function(context){
         var scope = $scope.$new();
         switch (context) {
         case 'faq':
          $window.location.href = scope.urlRoot + "/link_app/universe/faq";
          break;
         case 'pricing':
          $window.location.href = scope.urlRoot + "/link_app/universe/pricing";
          break;
        case 'universe_eula':
          $window.location.href = scope.urlRoot + "/link_app/universe/eula";
          break;
        case 'forgot_password':
          $window.location.href = scope.urlRoot + "/link_app/forgot_password";
          break;
        case 'create_account':
          $window.location.href = scope.urlRoot + "/link_app/create_account";
          break;
        case 'customer_support':
          $window.location.href = scope.urlRoot + "/link_app/customer_support";
          break;
        case 'universe_account':
          $window.location.href = scope.urlRoot + "/link_app/universe/account";
          break;
        case 'link_page':
          $window.location.href = scope.urlRoot + "/link";
          break;
        case 'account_settings':
          $window.location.href = scope.urlRoot + "/link_app/account_settings";
          break;
        case 'fcpx_universe_faq':
          $window.location.href = scope.urlRoot + "/link_app/universe/fcpx_faq";
          break;
        case 'universe_faq':
          $window.location.href = scope.urlRoot + "/link_app/universe/faq";
          break;
        default:
          $window.location.href = scope.urlRoot + "/link_app/universe/pricing";
          break;
        }
     };

      $scope.displayVideo = function(video) {
        var scope = $scope.$new();
        switch (video) {
        case 'tryUniverse':
          $window.location.href = scope.urlRoot + "/link_app/universe/video/try";
          break;
        case 'upgradeUniverse':
          $window.location.href = scope.urlRoot + "/link_app/universe/video/pricing";
          break;
        default:
          $window.location.href = scope.urlRoot + "/link_app/universe/video/try";
          break;
        }
      };

      $scope.displayDialogue = function() {
        if ($scope.dialogue.dialogueRevealed === true || (Dialogues.dialogueQueue.length === 0)) {
          return;
        }

        $modal.open({
          templateUrl: '/partials/_dialogue.html',
          scope: $scope,
          controller: 'DialogueController',
          windowClass: 'dialogue',
          backdrop: 'static',
          keyboard: false
        });

        $scope.dialogue.dialogueRevealed = true;
      };

      $scope.signOut = function() {
        CurrentUser.signOut();
      };

      $scope.enableRoaming = function() {
        $window.location.href = "rg://roaming_enable";
      };

      $scope.disableRoaming = function() {
        $window.location.href = "rg://roaming_disable";
      };

      $scope.showLogin = function(includeUniverseEULA, installUniverseAfter) {
        if (!$scope.appReady) {
          return;
        }

        var scope = $scope.$new();
        scope.includeUniverse = !!includeUniverseEULA;
        scope.installUniverseAfter = !!installUniverseAfter;

        if (!$scope.showLogin.visible) {
          $scope.showLogin.visible = true;
          $modal.open({
            templateUrl: '/partials/_login.html',
            controller: 'LoginController',
            windowClass: 'loginModal',
            scope: scope
          })
          .result.finally(function(){
            $scope.showLogin.visible = false;
          });
        }
      };

      $scope.showLogin.visible = false;

      $scope.showAbout = function() {
        if (!$scope.showAbout.visible) {
          $scope.showAbout.visible = true;
          $modal
            .open({
              templateUrl: '/partials/_about_box.html',
              scope: $scope,
              keyboard: false
            })
            .result.finally(function() {
              $scope.showAbout.visible = false;
            });
        }
      };
      $scope.showAbout.visible = false;

      $scope.isActive = function(viewLocation) {
        return (viewLocation === $location.path()) && $scope.appReady;
      };

      $scope.urlInitGate = function(url) {
        return (!$scope.offlineMode.active && $scope.appReady) ? url : '';
      };

      $scope.signUpUniverse = function() {
        $modal.open({
          templateUrl: '/partials/_universe_agreement_modal.html',
          scope: $scope,
          windowClass: 'loginModal'
        })
        .result.then(function() {
          $window.location.href = "rg://universe_signup";
          $window.location.href = "rg://download_universe";
        });
      };


      $scope.go = function (path) {
        $location.path(path);
      };

      $scope.setUpdateFrequency = function(freq) {
        CurrentUser.setUpdateFrequency(freq);
      };

    }]);
})();

(function() {
  'use strict';

  Link.App.controller('DialogueController',
    ['$scope', 'Dialogues', '$modalInstance', '$window',
    function($scope, Dialogues, $modalInstance, $window) {

      $scope.$watch(
        function() {
          return Dialogues.dialogueQueue;
        },
        function() {
          if (Dialogues.dialogueQueue.length === 0) {
            // $scope.title = "";
            // $scope.message = "";
            // $scope.buttons = [];
          } else {
            Dialogues.dialogueQueue[0].buttons = Dialogues.dialogueQueue[0].buttons || [];
            $scope.title = Dialogues.dialogueQueue[0].title;
            $scope.message = Dialogues.dialogueQueue[0].message;
            $scope.buttons = JSON.parse(JSON.stringify(Dialogues.dialogueQueue[0].buttons));
          }
        },
        true);

      $scope.close = function(maybeURL) {
        $modalInstance.dismiss('close');
        Dialogues.dialogueQueue.shift();
        $scope.dialogue.dialogueRevealed = false;
        if (maybeURL) {

          $window.setTimeout(function() {
            $window.location.href = maybeURL;
          }, 300);

        }
      };
    }]);
})();

(function() {
  'use strict';

  Link.App.controller('LoginController',
    ['$scope', '$q', '$http', 'CurrentUser', '$modalInstance',
    function($scope, $q, $http, CurrentUser, $modalInstance) {
      $scope.formData = {
        email: "",
        password: "",
        remember: false
      };

      $scope.formFillScolding = false;
      $scope.agreeToUniverseTerms = false;

      $scope.submit = function() {
        if ($scope.formData.email && $scope.formData.password) {
          $scope.logIn($scope.formData.email, $scope.formData.password);
          $modalInstance.close();
        } else {
          $scope.formFillScolding = true;
        }
      };

      $scope.cancel = function() {
        $modalInstance.dismiss('cancel');
      };

      $scope.logIn = function(email, password) {
        CurrentUser.setInstallUniverseAfterSignIn($scope.installUniverseAfter);
        CurrentUser.logIn(email, password, $scope.includeUniverse);
      };


    }]);
})();

(function() {
  'use strict';

  Link.App.controller('PreferencesFormController',
    ['$scope',
    function($scope) {
      $scope.domain = /^([a-zA-Z0-9\.])+(:\d{2,5})?$/;
    }]);
})();

(function() {
  'use strict';

  Link.App.controller('PreferencesModalController',
    ['$scope', '$modalInstance',
    function($scope, $modalInstance) {

      $scope.submit  = function(form) {
        var updateHttpProxy
          , updateHttpsProxy;

        $scope.$parent.httpProxyServer = form.httpProxyServer.$modelValue || '';
        $scope.$parent.httpsProxyServer = form.httpsProxyServer.$modelValue || '';
        $scope.$parent.httpProxyUser = form.httpProxyUser.$modelValue || '';
        $scope.$parent.httpsProxyUser = form.httpsProxyUser.$modelValue || '';
        $scope.$parent.httpProxyPassword = form.httpProxyPassword.$modelValue || '';
        $scope.$parent.httpsProxyPassword = form.httpsProxyPassword.$modelValue || '';

        updateHttpProxy = "rg://http_proxy?" + encodeURIComponent(form.httpProxyServer.$modelValue || '');
        updateHttpProxy += "&" + encodeURIComponent(form.httpProxyUser.$modelValue || '');
        updateHttpProxy += "&" + encodeURIComponent(form.httpProxyPassword.$modelValue || '');

        updateHttpsProxy = "rg://https_proxy?" + encodeURIComponent(form.httpsProxyServer.$modelValue);
        updateHttpsProxy += "&" + encodeURIComponent(form.httpsProxyUser.$modelValue || '');
        updateHttpsProxy += "&" + encodeURIComponent(form.httpsProxyPassword.$modelValue || '');

        window.setTimeout(function() {
          window.location.href = updateHttpProxy;
        }, 250);
        window.location.href = updateHttpsProxy;
        $modalInstance.close();
      };
    }]);
})();




(function() {
  'use strict';

  Link.App.controller('ProductController',
    ['$scope', '$q', '$http', 'ProductSource', 'CurrentUser', '$modal',
    function($scope, $q, $http, ProductSource, CurrentUser, $modal) {
      $scope.plugins = {freePluginCount: 0, premiumPluginCount: 0};
      $scope.viewStates = { accountSerialRolldowns: []  };
      $scope.ownedProducts = [];

      $scope.serialHovered = function(justArrived, event) {
        var selection = window.getSelection()
          , range;

        selection.removeAllRanges();

        if (justArrived) {
          range = document.createRange();
          range.selectNodeContents(event.toElement);
          selection.addRange(range);
        }

      };

      $scope.$watch(
        function() {
          return ProductSource.universePlugins;
        },
        function(universePlugins) {
          $scope.plugins = universePlugins;
          $scope.plugins.freePluginCount = $scope.plugins.free ? Object.keys($scope.plugins.free).length : 0;
          $scope.plugins.premiumPluginCount = $scope.plugins.premium ? Object.keys($scope.plugins.premium).length : 0;
        },
        true
      );

      $scope.$watch(
        function() {
          return ProductSource.products;
        }, function(products) {
          $scope.universeLegacyTools = ProductSource.getProductByCode(125);
          
          $scope.installedProducts = products.filter(installedProductsFilter).sort(productListOrder);
          $scope.betaProducts = products.filter(betaProductsFilter);
          $scope.updatedProducts = products.filter(updatedProductsFilter);

          $scope.universe = ProductSource.getProductByCode('UNIVERSE');

          $scope.isUniverseOneXInstalled = ($scope.universe && $scope.universe.version) ? ($scope.universe.version.split(".")[0] === '1') : false;
          $scope.isUniverseTwoXInstalled = ($scope.universe && $scope.universe.version) ? ($scope.universe.version.split(".")[0] === '2') : false;
          $scope.isUniverseThreeXInstalled = ($scope.universe && $scope.universe.version) ? ($scope.universe.version.split(".")[0] === '3') : false;
          $scope.isUniverseInstalled = ( $scope.isUniverseOneXInstalled ||  $scope.isUniverseTwoXInstalled || $scope.isUniverseThreeXInstalled);
        }, true);

      $scope.$watch(
        function() {
          return CurrentUser.ownedProducts();
        },
        function() {
          $scope.ownedProducts = CurrentUser.ownedProducts();
        }
      );


      $scope.$watch(
        function() {
          return CurrentUser.universePlan();
        },
        function() {
          var plan = CurrentUser.universePlan();

          $scope.isUniverseUser = (plan.status !== 'unregistered');
          
          $scope.isUniverseTrial = (plan.status === 'TRIAL' && parseInt(plan.daysLeft, 10) > 0);
          $scope.isUniverseExpired = (plan.status === 'EXPIRED') || (plan.status === 'TRIAL' && parseInt(plan.daysLeft, 10) === 0);
          
 
          $scope.isUniverseSubscriber = (plan.status === 'ACTIVE');
          $scope.universeAutorenews = plan.autorenews;
          $scope.universeExpirationDate = plan.expiresOn;

          $scope.universeTerm = plan.term;
          $scope.universeTermDaysLeft = plan.daysLeft;

          $scope.isUniverseEarlyAdopter = plan.legacy;

          $scope.universeStatus = plan.status;
          
          $scope.hasUniverseBonusTrial = false;
          $scope.universeBonusTrialOfferDaysLeft = 0;
          
        },
        true
      );

      $scope.$watch(
        function() {
          return ProductSource.state;
        }, function() {
          $scope.productsLoading = (ProductSource.state === 'initial');
          $scope.productsLoaded = (ProductSource.state === 'loaded');
          $scope.productsError = (ProductSource.state === 'error');
        });

      $scope.universeHostAppsModal = function() {
        if (!$scope.universe.isInstalled) {
          return;
        }

        if (!$scope.universeHostAppsModal.visible) {
          $scope.universeHostAppsModal.visible = true;
          $modal
            .open({
              templateUrl: '/partials/_universe_host_apps.html',
              scope: $scope
            })
            .result.finally(function() {
              $scope.universeHostAppsModal.visible = false;
            });
        }
      };
      $scope.universeHostAppsModal.visible = false;

      $scope.installUniverse = function() {
        ProductSource.installUniverse();
      };

      $scope.updateAll = function() {
        ProductSource.updateAll();
      };

      $scope.init = function() {
      };
    }]);

  function productListOrder(a, b) {
    var aScore = a.orderScore
      , bScore = b.orderScore;

    if (aScore > bScore) {
      return -1;
    } else if (aScore < bScore) {
      return 1;
    } else {
      if (a.title > b.title) {
        return 1;
      } else if (a.title < b.title) {
        return -1;
      }
      return 0;
    }
  }

  function betaProductsFilter(product) {
    return product.isBeta;
  }

  function updatedProductsFilter(product) {
    if (!installedProductsFilter(product)) {
      return false;
    }
    return !product.isUpToDate && !(product.isTrial && product.hasTrialExpired && !product.isIndefiniteTrial);
  }

  function installedProductsFilter(product) {
    var itIsPrimaryUniversePackageOrNotUniverseAtAll = !product.isUniverse || (product.isUniverse && product.code === 'UNIVERSE');
    return (itIsPrimaryUniversePackageOrNotUniverseAtAll && (product.isInstalled || product.isInstalling));
  }
})();

(function() {
  'use strict';

  Link.App.directive('buyuniversedropdown', function() {
    return {
      restrict: 'E',
      templateUrl: '/partials/_buy_universe_dropdown.html',
      replace: true,
      scope: {}
    };
  });

})();

(function() {
  'use strict';

  Link.App.directive('pluginentries', function() {
    return {
      restrict: 'E',
      templateUrl: '/partials/_plugin_entries.html',
      replace: true,
      scope: {
        plugins: '='
      }
    };
  });

})();

(function() {
  'use strict';

  Link.App.directive('pluginlist', function() {
    return {
      restrict: 'E',
      templateUrl: '/partials/_plugin_list.html',
      replace: true,
      scope: {
        visible: '=',
        plugins: '='
      },

      link: function( $scope) {
        $scope.$watch('plugins', function(plugins) {
          var helper = { totalWeight: 0,
              allThings: [],
              currentWeight: 0,
              currentRow: 0
            }
            , third
            , category_weight = 2;
          $scope.lists = [[],[],[]];

          Object.keys(plugins).sort().forEach( function(category) {
            helper.totalWeight += category_weight;
            helper.totalWeight += plugins[category].length;
            helper.allThings.push( {type: "category", value: {title: category}});
            plugins[category].forEach(function(plugin) {
              helper.allThings.push( {type: "plugin", value: plugin});
            });
          });
          third = Math.floor(helper.totalWeight / 3);

          helper.allThings.forEach(function(row) {
            if (row.type === 'plugin') {
              helper.currentWeight += 1;
            } else {
              helper.currentWeight += category_weight;
            }

            if (helper.currentWeight > third && row.type === 'category') {
              $scope.lists[helper.currentRow + 1].push(row);
            } else {
              $scope.lists[helper.currentRow].push(row);
            }

            if (helper.currentWeight > third) {
              helper.currentWeight = 0;
              helper.currentRow += 1;
              if (helper.currentRow > 2) {
                helper.currentRow = 2;
              }
            }

          });
        });
      }
    };
  });

})();

(function() {
  'use strict';

  var defaultUpgradePopoverTitle =  "Upgrade your product"
    , defaultUpgradePopoverBody =   "If you are enjoying this product, " +
                                    "consider upgrading to the latest version " +
                                    "for more features."
    , defaultExpiredTrialUpgradePopoverTitle = "Upgrade expired trial" // jshint ignore:line
    , defaultExpiredTrialUpgradePopoverBody = "Your trial has expired, but the upgrade " +// jshint ignore:line
                                    "is available for purchase.";

  Link.App.directive('product', ['$rootScope', 'CurrentUser', function($rootScope, CurrentUser) {
    return {
      restrict: 'E',
      templateUrl: '/partials/_product_entry.html',
      replace: true,

      scope: {
        product: "="
      },

      link: function($scope, $element, $attrs) {
        var stringBuilder;

        $scope.$watch('product', function(product) {
          if (!product) {
            return;
          }

          $scope.template = "installed";
          $scope.buttonToShow = "none";

          $scope.hasMoreInfo = false;
          $scope.moreInfoURI = "#";

          $scope.universe = product.isUniverse;
          $scope.installationPane = !!($attrs.installationpane);

          $scope.upToDate = product.isInstalled && product.isUpToDate && !product.isInstalling;

          if (product.progress !== -1) {
            $scope.template = "progress";
            return;
          } 

          if (!product.isUpToDate && ((!product.hasTrialExpired || (product.isIndefiniteTrial || product.isUniverse)))) {
            $scope.buttonToShow = "update";
            if (product.isUniverse) {
              $scope.buttonToShow = "download";
            }

            $scope.hasMoreInfo = (product.whatsNew instanceof Array) && (product.whatsNew.length > 0);
            $scope.moreInfoIcon = "question-sign";
            $scope.moreInfoText = "";
            $scope.moreInfoTitle = "What's New?";
            if (product.whatsNew instanceof Array) {
              if (product.whatsNew.length > 1) {
                stringBuilder = "<ul>";
                stringBuilder += product.whatsNew.reduce(function(all, current) {
                  return all + "<li>" + current + "</li>";
                }, "");
                stringBuilder += "<ul>";
                $scope.moreInfoBody = stringBuilder;
              } else {
                $scope.moreInfoBody = product.whatsNew[0];
              }
            } else {
              $scope.moreInfoBody = product.whatsNew;
            }
          } else if (!product.isInstalled && !product.isInstalling) {
            $scope.buttonToShow = "install";
          } else if (product.isTrial && product.isUniverse && !CurrentUser.isLoggedIn()) {
            $scope.buttonToShow = "none";
          } else if (product.isTrial && product.isUniverse) {
            $scope.buttonToShow = "universe_buy";
          } else if (product.upgradeURI) {
            $scope.buttonToShow = "upgrade";
            $scope.hasMoreInfo = true;
            $scope.moreInfoIcon = "info-sign";
            $scope.moreInfoText = "Learn more";
            $scope.moreInfoURI = product.upgradeInfoURI;
            $scope.moreInfoTitle = product.alternateHoverTitle || defaultUpgradePopoverTitle;
            $scope.moreInfoBody = product.alternateHoverBody || defaultUpgradePopoverBody;
          } else if (product.isTrial) {
            $scope.buttonToShow = "buy";
          } else if (product.isUpToDate && product.isUniverse && $scope.installationPane) {
            $scope.buttonToShow = "uninstall";
          }

          
        }, true);
      }
    };

  }]);
})();

(function() {
  'use strict';

  Link.App.directive('serialnumber', function() {
    return {
      restrict: 'E',
      templateUrl: '/partials/_serial_number.html',
      replace: true,
      transclude: true,
      scope: {
        number: '=',
        hide: '='
      },
      link: {}
    };
  });

})();

(function() {
  'use strict';

  Link.App.directive('throbber', function() {
    return {
      restrict: 'E',
      templateUrl: '/partials/_throbber.html',
      replace: true,
      scope: {},
      link: function($scope, $element, $attr) {
        $scope.throbbyStyle = {
          height: $attr.size,
          width: $attr.size
        };
      }
    };
  });

})();

(function() {
  'use strict';
  Link.App.filter('underscores_to_spaces', function () {
    return function (input) {
        return input.replace(/_/g, ' ');
    };
  });
  Link.App.filter('bytes', function() {
    return function(bytes, precision) {
      if (isNaN(parseFloat(bytes)) || !isFinite(bytes)) {
        return '-';
      }

      if (typeof precision === 'undefined') {
        precision = 1;
      }

      var units = ['bytes', 'kB', 'MB', 'GB', 'TB', 'PB'],
        number = Math.floor(Math.log(bytes) / Math.log(1024));
      return (bytes / Math.pow(1024, Math.floor(number))).toFixed(precision) +  ' ' + units[number];
    };
  });

})();

(function() {
  'use strict';

  Link.App.factory('CurrentUser',
    ['$rootScope', 'EventSource', '$window', function($rootScope, EventSource, $window) {
      var currentUser = {
        userData: {
          loggedIn: false,
          updateFrequency: "Weekly",
          universeTerm: "unregistered",
          installUniverseAfterSignIn: false,
          universeTermDaysLeft: 0,
          universeLegacy: false,
          ownedProducts: [],
          available_host_apps: [],
          isRoamingEnabled: false
        },
      };

      currentUser.messageHandler = function(message) {
        switch(message.type) {
        case 'update_frequency':
          currentUser.updateFrequencyUpdated(message.payload);
          return true;
        case 'owned_products':
          currentUser.setOwnedProducts(message.payload.products);
          return true;
        case 'user_data':
          currentUser.setUserData(message.payload);
          return true;
        case 'sign_out':
          currentUser.signedOut();
          return true;
        case 'available_host_apps':
          currentUser.setAvailableHostApps(message.payload);
          return true;
        case 'products_loaded':
          if (currentUser.userData.installUniverseAfterSignIn) {
            currentUser.userData.installUniverseAfterSignIn = false;
            $window.location.href = "rg://download_universe";
          }
          return false;
        case 'set_roaming': 
            currentUser.setRoamingIsEnabled(message.payload);
            return true;
        case 'universe_membership':
          currentUser.userData.universeStatus = message.payload.status;
          currentUser.userData.universeTerm = message.payload.term;
          currentUser.userData.universeTermDaysLeft = message.payload.daysLeft;
          currentUser.userData.universeLegacy = message.payload.isLegacy;
          currentUser.userData.universeAutorenews = message.payload.autorenews;
          currentUser.userData.universeExpiresOn = message.payload.expiresOn;

          if (message.payload.trialAvailableUntil) {
            currentUser.userData.universeTrialAvailableUntil = Link.Utils.parseDate(message.payload.trialAvailableUntil);
          } else {
            currentUser.userData.universeTrialAvailableUntil = false;
          }
          currentUser.userData.universeTrialAvailableDaysLeft = message.payload.trialAvailableDaysLeft;
          return true;
        }
        return false;
      };

      currentUser.setInstallUniverseAfterSignIn = function(value) {
        currentUser.userData.installUniverseAfterSignIn = value;
      };

      currentUser.setOwnedProducts = function(newProducts) {
        currentUser.userData.ownedProducts = newProducts;
      };

      currentUser.setUserData = function(newData) {
        currentUser.userData.email = newData.email;
        currentUser.userData.loggedIn = newData.loggedIn;
        currentUser.userData.isRoamingEnabled = newData.isRoamingEnabled;
      };

     currentUser.setAvailableHostApps = function(newData) {
        currentUser.userData.available_host_apps = newData;
     };

      currentUser.updateFrequencyUpdated = function(newValue) {
        var capitalized = newValue.charAt(0).toUpperCase() + newValue.slice(1);
        currentUser.userData.updateFrequency = capitalized;
      };
      currentUser.setRoamingIsEnabled = function(newValue) {
        currentUser.userData.isRoamingEnabled = newValue;
      };

      currentUser.isRoamingEnabled = function() {
        return currentUser.userData.isRoamingEnabled;
      };

      currentUser.universePlan = function() {
        return {
          status: currentUser.userData.universeStatus,
          term: currentUser.userData.universeTerm,
          daysLeft: currentUser.userData.universeTermDaysLeft,
          legacy: currentUser.userData.universeLegacy,
          autorenews: currentUser.userData.universeAutorenews,
          expiresOn: currentUser.userData.universeExpiresOn,
          trialAvailableUntil: currentUser.userData.universeTrialAvailableUntil,
          trialAvailableDaysLeft: currentUser.userData.universeTrialAvailableDaysLeft
        };
      };

      currentUser.getUpdateFrequency = function() {
        return currentUser.userData.updateFrequency;
      };

      currentUser.getEmailAddress = function() {
        return currentUser.userData.email;
      };

     currentUser.getAvailableHosts = function() {
        return currentUser.userData.available_host_apps;
     };

      currentUser.ownedProducts = function() {
        return currentUser.userData.ownedProducts;
      };

      currentUser.isLoggedIn = function() {
        return currentUser.userData.loggedIn;
      };

      currentUser.logIn = function(username, password, registerForUniverse) {
        var uri = "rg://login?" + encodeURIComponent(username) + "&" + encodeURIComponent(password);

        if (registerForUniverse) {
          uri += "&register_for_universe";
        }

        $window.location.href = uri;
      };

      currentUser.signedOut = function() {
        currentUser.userData.loggedIn = false;
      };

      currentUser.signOut = function() {
        $window.location.href = "rg://signout";
      };

      currentUser.setUpdateFrequency = function(freq) {
        $window.location.href = "rg://frequency?" + freq;
      };

      EventSource.subscribe(currentUser.messageHandler);
      return currentUser;
    }]);
})();

(function() {
  'use strict';

  Link.App.factory('Dialogues',
    ['$rootScope', 'EventSource', function($rootScope, EventSource) {

    var dialogueService = {
      dialogueQueue: []
    };

    dialogueService.messageHandler = function(message) {
      switch(message.type) {
      case 'dialog':
        dialogueService.dialogueArrived(message.payload);
        return true;
      }
      return false;
    };

    dialogueService.dialogueArrived = function(message) {
      dialogueService.dialogueQueue.push(message);
    };

    EventSource.subscribe(dialogueService.messageHandler);

    return dialogueService;
  }]);
})();

(function() {
  'use strict';

  Link.App.factory('EventSource', ['$rootScope', function($rootScope) {

      var eventSource = {
          inLinkApp: false
        }
        , handlers = [];

      eventSource.broadcast = function(message) {
        var errorString = "";
        message = [].concat(message);
        handlers.forEach(function(handler){
          message.forEach(function(message) {
            try {
              var digestAfter = handler(message);

              if (digestAfter) {
                $rootScope.$digest();
              }

            } catch(e) {
              if (errorString !== "") {
                errorString += ",";
              }
              errorString += "" + e;
            }
          });
        });

        if (errorString.length > 0) {
          return errorString;
        }
      };

      eventSource.subscribe = function(handler) {
        handlers.push(handler);
      };

      eventSource.runningInProduction = function() {
        eventSource.inLinkApp = true;
        $rootScope.$digest();
      };

      eventSource.runningInDebug = function() {
        eventSource.inLinkApp = false;
        $rootScope.$digest();
      };

      /* global window: false */
      window.bridge = eventSource;
      /* global -window */

      return eventSource;
    }]);

})();

(function() {
  'use strict';

  Link.App.factory('ProductSource', ['$http', '$q', '$rootScope', 'EventSource', '$window',
    function($http, $q, $rootScope, EventSource, $window) {
      var productSource = {
          state: 'initial',
          products: [],
          universePlugins: {}
        }
        , productUpdateInterval = 200
        , productUpdateRateRegulator = {};


      productSource.messageHandler = function(message) {
        switch(message.type) {
        case 'all_products':
          productSource.updateAllProducts(message.payload);
          return true;
        case 'product_reload_starting':
          productSource.reloadStarting();
          return true;
        case 'set_loading':
          productSource.setLoading(message.payload);
          return true;
        case 'update_product':
          return productSource.updateProducts([].concat(message.payload));
        case 'universe_plugins':
          productSource.setUniversePlugins(message.payload);
          return true;
        }
        return false;
      };

      productSource.updateAll = function() {
        $window.location.href = "rg://updateall";
      };

      productSource.installUniverse = function() {
        $window.location.href = "rg://install_universe";
      };

      productSource.setLoading = function(loading) {
        if (loading === true) {
          productSource.state = "initial";
        } else {
          productSource.state = "loaded";
        }
      };

      productSource.reloadStarting = function() {
        productSource.state = "initial";
        productSource.products = [];
      };

      productSource.setUniversePlugins = function(payload) {
        productSource.universePlugins = payload.plugins;
      };

      productSource.updateAllProducts = function(payload) {
        productSource.products = payload.map(Link.Product);
        productSource.state = "loaded";
        EventSource.broadcast({type: "products_loaded", payload: ""});
      };

      productSource.getProductByCode = function(code) {
        var filtered = productSource.products.filter(function(product) {
          return (product.code === code);
        });
        return filtered[0];
      };

      productSource.getProductIndexByCode = function(code) {
        var toReturn = -1;
        productSource.products.forEach(function(product, index) {
          if (product.code === code) {
            toReturn = index;
          }
        });
        return toReturn;
      };

      productSource.updateProducts = function(products) {
        return products
                  .map(productSource.updateProduct)
                  .some(function(digestAfter) {return digestAfter;});
      };

      productSource.updateProduct = function(def) {
        var productIndex = productSource.getProductIndexByCode(def.code);

        if (productIndex === -1) {
          productSource.products.push(new Link.Product(def));
          return true;
        }

        if (productUpdateRateRegulator[productIndex]) {
          productUpdateRateRegulator[productIndex].definition = def;
        } else {
          productUpdateRateRegulator[productIndex] = {
            update: function() {
              productSource.products[productIndex].updateFromDefinition(productUpdateRateRegulator[productIndex].definition);
              productUpdateRateRegulator[productIndex] = null;
              $rootScope.$digest();
            },
            definition: def
          };
          $window.setTimeout(productUpdateRateRegulator[productIndex].update, productUpdateInterval);
        }

        return false;
      };

      EventSource.subscribe(productSource.messageHandler);
      return productSource;
    }]);

})();

angular.module('linkApp').run(['$templateCache', function($templateCache) {
  'use strict';

  $templateCache.put('/partials/_about_box.html',
    "<div class=\"modal-header\">\n" +
    "  <button type=\"button\" class=\"close\" ng-click=\"$close()\">×</button>\n" +
    "  <h4 class=\"modal-title\">About {{linkName}} v{{linkVersion}}</h4>\n" +
    "</div>\n" +
    "<div class=\"modal-body about-box\">\n" +
    "  <p><strong>Red Giant Link</strong> is a tool for keeping your Red Giant software products and plugins up-to-date. Link compares the versions of the Red Giant software you have installed against those on our update server. Should a newer version become available, you can download and install it immediately through Link.</p>\n" +
    "\n" +
    "  <p>Running the latest version of your software ensures the best possible experience, as updates contain new features, increased compatibility, bug fixes, and performance enhancements.</p>\n" +
    "\n" +
    "  <p><strong>All Red Giant software updates are free.</strong></p>\n" +
    "\n" +
    "  <p>More information about Red Giant Link is available on our <a ng-click=\"visitMothership('link_page')\">website</a>.</p>\n" +
    "\n" +
    "\n" +
    "  <hr>\n" +
    "  <h4>Open Source Libraries</h4>\n" +
    "  <p>Link makes use of the following open source libraries, they can be expanded to review their licenses:</p>\n" +
    "\n" +
    "    <accordion close-others>\n" +
    "      <accordion-group heading=\"CEF Python\">\n" +
    "<tt>Copyright (c) 2012-2013 Czarek Tomczak. Portions Copyright\n" +
    "(c) 2008-2013 Marshall A.Greenblatt, 2006-2009 Google Inc.\n" +
    "All rights reserved.\n" +
    "\n" +
    "Redistribution and use in source and binary forms, with\n" +
    "or without modification, are permitted provided that the\n" +
    "following conditions are met:\n" +
    "\n" +
    "* Redistributions of source code must retain the above\n" +
    "  copyright notice, this list of conditions and the\n" +
    "  following disclaimer.\n" +
    "\n" +
    "* Redistributions in binary form must reproduce the above\n" +
    "  copyright notice, this list of conditions and the\n" +
    "  following disclaimer in the documentation and/or other\n" +
    "  materials provided with the distribution.\n" +
    "\n" +
    "* Neither the name of Google Inc. nor the name Chromium\n" +
    "  Embedded Framework nor the name of CEF Python nor the\n" +
    "  names of its contributors may be used to endorse or\n" +
    "  promote products derived from this software without\n" +
    "  specific prior written permission.\n" +
    "\n" +
    "THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND\n" +
    "CONTRIBUTORS \"AS IS\" AND ANY EXPRESS OR IMPLIED WARRANTIES,\n" +
    "INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF\n" +
    "MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE\n" +
    "DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR\n" +
    "CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,\n" +
    "SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT\n" +
    "NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;\n" +
    "LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)\n" +
    "HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN\n" +
    "CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE\n" +
    "OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS\n" +
    "SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</tt>\n" +
    "      </accordion-group>\n" +
    "\n" +
    "      <accordion-group heading=\"Cython\">\n" +
    "<tt>                                 Apache License\n" +
    "                           Version 2.0, January 2004\n" +
    "                        http://www.apache.org/licenses/\n" +
    "\n" +
    "   TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION\n" +
    "\n" +
    "   1. Definitions.\n" +
    "\n" +
    "      \"License\" shall mean the terms and conditions for use, reproduction,\n" +
    "      and distribution as defined by Sections 1 through 9 of this document.\n" +
    "\n" +
    "      \"Licensor\" shall mean the copyright owner or entity authorized by\n" +
    "      the copyright owner that is granting the License.\n" +
    "\n" +
    "      \"Legal Entity\" shall mean the union of the acting entity and all\n" +
    "      other entities that control, are controlled by, or are under common\n" +
    "      control with that entity. For the purposes of this definition,\n" +
    "      \"control\" means (i) the power, direct or indirect, to cause the\n" +
    "      direction or management of such entity, whether by contract or\n" +
    "      otherwise, or (ii) ownership of fifty percent (50%) or more of the\n" +
    "      outstanding shares, or (iii) beneficial ownership of such entity.\n" +
    "\n" +
    "      \"You\" (or \"Your\") shall mean an individual or Legal Entity\n" +
    "      exercising permissions granted by this License.\n" +
    "\n" +
    "      \"Source\" form shall mean the preferred form for making modifications,\n" +
    "      including but not limited to software source code, documentation\n" +
    "      source, and configuration files.\n" +
    "\n" +
    "      \"Object\" form shall mean any form resulting from mechanical\n" +
    "      transformation or translation of a Source form, including but\n" +
    "      not limited to compiled object code, generated documentation,\n" +
    "      and conversions to other media types.\n" +
    "\n" +
    "      \"Work\" shall mean the work of authorship, whether in Source or\n" +
    "      Object form, made available under the License, as indicated by a\n" +
    "      copyright notice that is included in or attached to the work\n" +
    "      (an example is provided in the Appendix below).\n" +
    "\n" +
    "      \"Derivative Works\" shall mean any work, whether in Source or Object\n" +
    "      form, that is based on (or derived from) the Work and for which the\n" +
    "      editorial revisions, annotations, elaborations, or other modifications\n" +
    "      represent, as a whole, an original work of authorship. For the purposes\n" +
    "      of this License, Derivative Works shall not include works that remain\n" +
    "      separable from, or merely link (or bind by name) to the interfaces of,\n" +
    "      the Work and Derivative Works thereof.\n" +
    "\n" +
    "      \"Contribution\" shall mean any work of authorship, including\n" +
    "      the original version of the Work and any modifications or additions\n" +
    "      to that Work or Derivative Works thereof, that is intentionally\n" +
    "      submitted to Licensor for inclusion in the Work by the copyright owner\n" +
    "      or by an individual or Legal Entity authorized to submit on behalf of\n" +
    "      the copyright owner. For the purposes of this definition, \"submitted\"\n" +
    "      means any form of electronic, verbal, or written communication sent\n" +
    "      to the Licensor or its representatives, including but not limited to\n" +
    "      communication on electronic mailing lists, source code control systems,\n" +
    "      and issue tracking systems that are managed by, or on behalf of, the\n" +
    "      Licensor for the purpose of discussing and improving the Work, but\n" +
    "      excluding communication that is conspicuously marked or otherwise\n" +
    "      designated in writing by the copyright owner as \"Not a Contribution.\"\n" +
    "\n" +
    "      \"Contributor\" shall mean Licensor and any individual or Legal Entity\n" +
    "      on behalf of whom a Contribution has been received by Licensor and\n" +
    "      subsequently incorporated within the Work.\n" +
    "\n" +
    "   2. Grant of Copyright License. Subject to the terms and conditions of\n" +
    "      this License, each Contributor hereby grants to You a perpetual,\n" +
    "      worldwide, non-exclusive, no-charge, royalty-free, irrevocable\n" +
    "      copyright license to reproduce, prepare Derivative Works of,\n" +
    "      publicly display, publicly perform, sublicense, and distribute the\n" +
    "      Work and such Derivative Works in Source or Object form.\n" +
    "\n" +
    "   3. Grant of Patent License. Subject to the terms and conditions of\n" +
    "      this License, each Contributor hereby grants to You a perpetual,\n" +
    "      worldwide, non-exclusive, no-charge, royalty-free, irrevocable\n" +
    "      (except as stated in this section) patent license to make, have made,\n" +
    "      use, offer to sell, sell, import, and otherwise transfer the Work,\n" +
    "      where such license applies only to those patent claims licensable\n" +
    "      by such Contributor that are necessarily infringed by their\n" +
    "      Contribution(s) alone or by combination of their Contribution(s)\n" +
    "      with the Work to which such Contribution(s) was submitted. If You\n" +
    "      institute patent litigation against any entity (including a\n" +
    "      cross-claim or counterclaim in a lawsuit) alleging that the Work\n" +
    "      or a Contribution incorporated within the Work constitutes direct\n" +
    "      or contributory patent infringement, then any patent licenses\n" +
    "      granted to You under this License for that Work shall terminate\n" +
    "      as of the date such litigation is filed.\n" +
    "\n" +
    "   4. Redistribution. You may reproduce and distribute copies of the\n" +
    "      Work or Derivative Works thereof in any medium, with or without\n" +
    "      modifications, and in Source or Object form, provided that You\n" +
    "      meet the following conditions:\n" +
    "\n" +
    "      (a) You must give any other recipients of the Work or\n" +
    "          Derivative Works a copy of this License; and\n" +
    "\n" +
    "      (b) You must cause any modified files to carry prominent notices\n" +
    "          stating that You changed the files; and\n" +
    "\n" +
    "      (c) You must retain, in the Source form of any Derivative Works\n" +
    "          that You distribute, all copyright, patent, trademark, and\n" +
    "          attribution notices from the Source form of the Work,\n" +
    "          excluding those notices that do not pertain to any part of\n" +
    "          the Derivative Works; and\n" +
    "\n" +
    "      (d) If the Work includes a \"NOTICE\" text file as part of its\n" +
    "          distribution, then any Derivative Works that You distribute must\n" +
    "          include a readable copy of the attribution notices contained\n" +
    "          within such NOTICE file, excluding those notices that do not\n" +
    "          pertain to any part of the Derivative Works, in at least one\n" +
    "          of the following places: within a NOTICE text file distributed\n" +
    "          as part of the Derivative Works; within the Source form or\n" +
    "          documentation, if provided along with the Derivative Works; or,\n" +
    "          within a display generated by the Derivative Works, if and\n" +
    "          wherever such third-party notices normally appear. The contents\n" +
    "          of the NOTICE file are for informational purposes only and\n" +
    "          do not modify the License. You may add Your own attribution\n" +
    "          notices within Derivative Works that You distribute, alongside\n" +
    "          or as an addendum to the NOTICE text from the Work, provided\n" +
    "          that such additional attribution notices cannot be construed\n" +
    "          as modifying the License.\n" +
    "\n" +
    "      You may add Your own copyright statement to Your modifications and\n" +
    "      may provide additional or different license terms and conditions\n" +
    "      for use, reproduction, or distribution of Your modifications, or\n" +
    "      for any such Derivative Works as a whole, provided Your use,\n" +
    "      reproduction, and distribution of the Work otherwise complies with\n" +
    "      the conditions stated in this License.\n" +
    "\n" +
    "   5. Submission of Contributions. Unless You explicitly state otherwise,\n" +
    "      any Contribution intentionally submitted for inclusion in the Work\n" +
    "      by You to the Licensor shall be under the terms and conditions of\n" +
    "      this License, without any additional terms or conditions.\n" +
    "      Notwithstanding the above, nothing herein shall supersede or modify\n" +
    "      the terms of any separate license agreement you may have executed\n" +
    "      with Licensor regarding such Contributions.\n" +
    "\n" +
    "   6. Trademarks. This License does not grant permission to use the trade\n" +
    "      names, trademarks, service marks, or product names of the Licensor,\n" +
    "      except as required for reasonable and customary use in describing the\n" +
    "      origin of the Work and reproducing the content of the NOTICE file.\n" +
    "\n" +
    "   7. Disclaimer of Warranty. Unless required by applicable law or\n" +
    "      agreed to in writing, Licensor provides the Work (and each\n" +
    "      Contributor provides its Contributions) on an \"AS IS\" BASIS,\n" +
    "      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or\n" +
    "      implied, including, without limitation, any warranties or conditions\n" +
    "      of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A\n" +
    "      PARTICULAR PURPOSE. You are solely responsible for determining the\n" +
    "      appropriateness of using or redistributing the Work and assume any\n" +
    "      risks associated with Your exercise of permissions under this License.\n" +
    "\n" +
    "   8. Limitation of Liability. In no event and under no legal theory,\n" +
    "      whether in tort (including negligence), contract, or otherwise,\n" +
    "      unless required by applicable law (such as deliberate and grossly\n" +
    "      negligent acts) or agreed to in writing, shall any Contributor be\n" +
    "      liable to You for damages, including any direct, indirect, special,\n" +
    "      incidental, or consequential damages of any character arising as a\n" +
    "      result of this License or out of the use or inability to use the\n" +
    "      Work (including but not limited to damages for loss of goodwill,\n" +
    "      work stoppage, computer failure or malfunction, or any and all\n" +
    "      other commercial damages or losses), even if such Contributor\n" +
    "      has been advised of the possibility of such damages.\n" +
    "\n" +
    "   9. Accepting Warranty or Additional Liability. While redistributing\n" +
    "      the Work or Derivative Works thereof, You may choose to offer,\n" +
    "      and charge a fee for, acceptance of support, warranty, indemnity,\n" +
    "      or other liability obligations and/or rights consistent with this\n" +
    "      License. However, in accepting such obligations, You may act only\n" +
    "      on Your own behalf and on Your sole responsibility, not on behalf\n" +
    "      of any other Contributor, and only if You agree to indemnify,\n" +
    "      defend, and hold each Contributor harmless for any liability\n" +
    "      incurred by, or claims asserted against, such Contributor by reason\n" +
    "      of your accepting any such warranty or additional liability.\n" +
    "\n" +
    "   END OF TERMS AND CONDITIONS\n" +
    "</tt>\n" +
    "      </accordion-group>\n" +
    "      <accordion-group heading=\"PyObjC\">\n" +
    "<tt>(This is the MIT license, note that libffi-src is a separate product with its\n" +
    "own license)\n" +
    "\n" +
    "Copyright 2002, 2003 - Bill Bumgarner, Ronald Oussoren, Steve Majewski,\n" +
    "Lele Gaifax, et.al.\n" +
    "\n" +
    "Copyright 2003-2013 - Ronald Oussoren\n" +
    "\n" +
    "Permission is hereby granted, free of charge, to any person obtaining a copy of\n" +
    "this software and associated documentation files (the \"Software\"), to deal in\n" +
    "the Software without restriction, including without limitation the rights to\n" +
    "use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of\n" +
    "the Software, and to permit persons to whom the Software is furnished to do so,\n" +
    "subject to the following conditions:\n" +
    "\n" +
    "The above copyright notice and this permission notice shall be included in all\n" +
    "copies or substantial portions of the Software.\n" +
    "\n" +
    "THE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\n" +
    "IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\n" +
    "FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\n" +
    "AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\n" +
    "LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,\n" +
    "OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE\n" +
    "SOFTWARE.\n" +
    "</tt>\n" +
    "      </accordion-group>\n" +
    "    </accordion>\n" +
    "</div>\n" +
    "\n" +
    "<div class=\"modal-footer\">\n" +
    "  <button class=\"btn btn-default\" ng-click=\"$close()\" autofocus>OK</button>\n" +
    "</div>\n"
  );


  $templateCache.put('/partials/_buy_universe_dropdown.html',
    "<ul class=\"dropdown-menu\">\n" +
    "  <li><a href=\"rg://buy_universe?year\">Annual</a></li>\n" +
    "</ul>\n"
  );


  $templateCache.put('/partials/_dialogue.html',
    "<div class=\"modal-header\">\n" +
    "  <h4 class=\"modal-title\">{{title}}</h4>\n" +
    "</div>\n" +
    "<div class=\"modal-body\">\n" +
    "  {{message}}\n" +
    "</div>\n" +
    "\n" +
    "<div ng-if=\"buttons.length === 0\" class=\"modal-footer\">\n" +
    "  <button class=\"btn btn-primary\" ng-click=\"close()\">OK</button>\n" +
    "</div>\n" +
    "\n" +
    "<div ng-if=\"buttons.length > 0\" class=\"modal-footer\">\n" +
    "  <button ng-repeat=\"button in buttons\" class=\"btn btn-default\" ng-click=\"close(button.link)\">{{button.text}}</button>\n" +
    "</div>\n"
  );


  $templateCache.put('/partials/_login.html',
    "<div class=\"modal-header\">\n" +
    "  <button type=\"button\" class=\"close\" ng-click=\"cancel()\">&times;</button>\n" +
    "  <h4 class=\"modal-title\" ng-if=\"!includeUniverse\">Sign In</h4>\n" +
    "  <h4 class=\"modal-title\" ng-if=\"includeUniverse\">Sign In &amp; Universe Agreement</h4>\n" +
    "</div>\n" +
    "\n" +
    "<div class=\"modal-body\">\n" +
    "  <p ng-show=\"includeUniverse\">Sign in with your Red Giant ID and make sure to agree to the End User License Agreement. Once you do that, you'll be able to start downloading the Universe library of effects and transitions immediately.</p>\n" +
    "\n" +
    "  <form role=\"form\" id=\"loginForm\" ng-submit=\"submit()\">\n" +
    "    <div class=\"form-group\">\n" +
    "      <label class=\"control-label\" for=\"inputEmail\">Red Giant ID:</label>\n" +
    "      <input  class=\"form-control\" focus-me tabindex=\"1\" type=\"text\" id=\"inputEmail\" placeholder=\"Red Giant ID\" ng-model=\"formData.email\">\n" +
    "      <p><small><a tabindex=\"-1\" ng-click=\"visitMothership('create_account')\">Don't have a Red Giant ID? Create one.</a></small></p>\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"form-group\">\n" +
    "      <label class=\"control-label\" for=\"inputPassword\" >Password:</label>\n" +
    "      <input class=\"form-control\" type=\"password\" tabindex=\"2\" id=\"inputPassword\" placeholder=\"Password\" ng-model=\"formData.password\">\n" +
    "      <p><small><a tabindex=\"-1\" ng-click=\"visitMothership('forgot_password')\">Forgot your password?</a></small></p>\n" +
    "    </div>\n" +
    "\n" +
    "    <p class=\"text-danger\" ng-show=\"formFillScolding\">Please enter a username and a password.</p>\n" +
    "    <p ng-show=\"!formFillScolding\">&nbsp;</p>\n" +
    "\n" +
    "    <div class=\"form-group\">\n" +
    "      <p class=\"help-block\" ng-show=\"!includeUniverse\">\n" +
    "        By signing in you agree to the <a ng-click=\"visitMothership('universe_eula')\">End User License Agreement</a>.\n" +
    "      </p>\n" +
    "\n" +
    "      <div class=\"checkbox\" ng-show=\"includeUniverse\">\n" +
    "        <label for=\"universeTerms\">\n" +
    "          <input type=\"checkbox\" ng-model=\"agreeToUniverseTerms\" id=\"universeTerms\">\n" +
    "          I agree to the Universe <a tabindex=\"-1\" ng-click=\"visitMothership('universe_eula')\">End User License Agreement</a>\n" +
    "        </label>\n" +
    "      </div>\n" +
    "    </div>\n" +
    "\n" +
    "  </form>\n" +
    "  <div class=\"pull-right\">\n" +
    "    <button class=\"btn btn-default\" tabindex=\"4\" ng-click=\"cancel()\">Cancel</button>\n" +
    "    <button class=\"btn btn-primary\" form=\"loginForm\"\n" +
    "            type=\"submit\"\n" +
    "            ng-disabled=\"(includeUniverse && !agreeToUniverseTerms)\"\n" +
    "            tabindex=\"3\"\n" +
    "            >Sign In</button>\n" +
    "  </div>\n" +
    "</div>\n" +
    "\n"
  );


  $templateCache.put('/partials/_offline_mode.html',
    "<div class=\"container-fluid offline-mode\">\n" +
    "  <div class=\"row\">\n" +
    "\n" +
    "    <div ng-if=\"!offlineMode.forced\" class=\"col-xs-12\">\n" +
    "      <h2>Connection Error</h2>\n" +
    "      <p>We’re sorry, Link was not able to connect to the Red Giant servers.</p>\n" +
    "      <p>If this problem persists, please check your internet connection then <a ng-click=\"escapeOfflineMode()\">try again</a> or contact <a ng-click=\"visitMothership('customer_support')\">Customer Support</a>.</p>\n" +
    "    </div>\n" +
    "\n" +
    "    <div ng-if=\"offlineMode.forced\" class=\"col-xs-12\">\n" +
    "      <h2>Unable to Establish a Secure Connection</h2>\n" +
    "      <div ng-if=\"offlineMode.blurb\" class=\"alert alert-danger\">{{offlineMode.blurb}}</div>\n" +
    "      <p>Link could not establish a secure connection to the Red Giant servers. This might be a temporary problem or you might need to download the latest version of Link.</p>\n" +
    "      <p>Please visit <a ng-click=\"visitMothership('link_page')\">our website</a> for more information.</p>\n" +
    "    </div>\n" +
    "  </div>\n" +
    "</div>\n"
  );


  $templateCache.put('/partials/_plugin_entries.html',
    "<div\n" +
    "    ng-repeat=\"plugin in plugins\"\n" +
    "    ng-class=\"{category: (plugin.type === 'category'), plugin: (plugin.type === 'plugin')}\">\n" +
    "  <span ng-if=\"plugin.value.status === 'new'\" class=\"label label-default plugin_status\">New</span>\n" +
    "  <span class=\"title\">{{plugin.value.title | underscores_to_spaces}}</span>\n" +
    "</div>\n"
  );


  $templateCache.put('/partials/_plugin_list.html',
    "<div class=\"row plugin_list\" collapse=\"!visible\">\n" +
    "  <div class=\"col-xs-4\">\n" +
    "    <pluginentries plugins=\"lists[0]\"></pluginentries>\n" +
    "  </div>\n" +
    "  <div class=\"col-xs-4\">\n" +
    "    <pluginentries plugins=\"lists[1]\"></pluginentries>\n" +
    "  </div>\n" +
    "  <div class=\"col-xs-4\">\n" +
    "    <pluginentries plugins=\"lists[2]\"></pluginentries>\n" +
    "  </div>\n" +
    "</div>\n"
  );


  $templateCache.put('/partials/_preferences_modal.html',
    "<div class=\"modal-body\">\n" +
    "  <form role=\"form\" class=\"form-horizontal\" id=\"preferencesForm\" ng-controller=\"PreferencesFormController\" name=\"preferencesForm\" ng-submit=\"submit(preferencesForm)\">\n" +
    "\n" +
    "    <div class=\"row\" style=\"padding-bottom: 10px;\">\n" +
    "      <div class=\"col-xs-12\"><strong>Preferences</strong></div>\n" +
    "    </div>\n" +
    "    <div class=\"well\" style=\"padding-top: 10px;\">\n" +
    "      <div class=\"row\" style=\"padding-bottom: 10px;\">\n" +
    "        <div class=\"col-xs-12\">\n" +
    "            <label>HTTP Proxy Server and Port</label>\n" +
    "            <input  class=\"form-control\"\n" +
    "                    type=\"text\"\n" +
    "                    placeholder=\"proxyserver:1234\"\n" +
    "                    name=\"httpProxyServer\"\n" +
    "                    ng-model=\"httpProxyServer\"\n" +
    "                    ng-pattern=\"domain\"\n" +
    "                    ng-trim=\"true\" />\n" +
    "        </div>\n" +
    "      </div>\n" +
    "      <div class=\"row\">\n" +
    "        <div class=\"col-xs-6\">\n" +
    "          <label for=\"httpProxyUser\">Username</label>\n" +
    "          <input  class=\"form-control\"\n" +
    "                  type=\"text\" name=\"httpProxyUser\" ng-model=\"httpProxyUser\" ng-trim=\"true\" />\n" +
    "        </div>\n" +
    "        <div class=\"col-xs-6\">\n" +
    "          <label>Password</label>\n" +
    "          <input class=\"form-control\" type=\"password\" name=\"httpProxyPassword\" ng-model=\"httpProxyPassword\" ng-trim=\"true\" />\n" +
    "        </div>\n" +
    "      </div>\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"well\" style=\"padding-top: 10px;\">\n" +
    "      <div class=\"row\" style=\"padding-bottom: 10px;\">\n" +
    "        <div class=\"col-xs-12\">\n" +
    "          <label>Secure Proxy Server and Port</label>\n" +
    "          <input  class=\"form-control\"\n" +
    "                  type=\"text\"\n" +
    "                  placeholder=\"proxyserver:1234\"\n" +
    "                  name=\"httpsProxyServer\"\n" +
    "                  ng-model=\"httpsProxyServer\"\n" +
    "                  ng-pattern=\"domain\"\n" +
    "                  ng-trim=\"true\" />\n" +
    "        </div>\n" +
    "      </div>\n" +
    "      <div class=\"row\">\n" +
    "        <div class=\"col-xs-6\">\n" +
    "          <label for=\"httpsProxyUser\">Username</label>\n" +
    "          <input  class=\"form-control\"\n" +
    "                  type=\"text\" name=\"httpsProxyUser\" ng-model=\"httpsProxyUser\" ng-trim=\"true\" />\n" +
    "        </div>\n" +
    "        <div class=\"col-xs-6\">\n" +
    "          <label>Password</label>\n" +
    "          <input class=\"form-control\" type=\"password\" name=\"httpsProxyPassword\" ng-model=\"httpsProxyPassword\" ng-trim=\"true\" />\n" +
    "        </div>\n" +
    "      </div>\n" +
    "    </div>\n" +
    "    <p class=\"help-block\">\n" +
    "      <span ng-show=\"(preferencesForm.httpProxyServer.$valid && preferencesForm.httpsProxyServer.$valid)\">&nbsp;</span>\n" +
    "      <span ng-show=\"(!preferencesForm.httpProxyServer.$valid || !preferencesForm.httpsProxyServer.$valid)\">Please ensure all server addresses are valid or blank.</span>\n" +
    "    </p>\n" +
    "    <button ng-disabled=\"!(preferencesForm.httpsProxyServer.$valid && preferencesForm.httpProxyServer.$valid)\"\n" +
    "            form=\"preferencesForm\"\n" +
    "            type=\"submit\"\n" +
    "            class=\"btn btn-primary\">Save</button>\n" +
    "    <button type=\"button\" class=\"btn btn-default\" ng-click=\"$close()\">Cancel</button>\n" +
    "  </form>\n" +
    "</div>\n" +
    "\n"
  );


  $templateCache.put('/partials/_product_entry.html',
    "<div class=\"row product_entry\" ng-class=\"{universe: universe, no_hover: installationPane}\">\n" +
    "  <!-- They all have a title on one side-->\n" +
    "  <div class=\"col-xs-6 title\">\n" +
    "    <span class=\"name\">{{product.title}}</span>\n" +
    "    <span class=\"version\">{{product.version}}</span>\n" +
    "\n" +
    "    <span ng-if=\"product.isTrial && !(product.isUniverse && installationPane)\">\n" +
    "      <span class=\"trial\">Trial</span>\n" +
    "      <span ng-if=\"!product.hasTrialExpired && !product.isIndefiniteTrial\" class=\"trial\">\n" +
    "        ({{product.trialDaysLeft}} day{{product.trialDaysLeft !== 1 ? 's' : ''}} left)\n" +
    "      </span>\n" +
    "      <span ng-if=\"product.hasTrialExpired\" class=\"trial\">\n" +
    "        Expired\n" +
    "    </span>\n" +
    "\n" +
    "  </div>\n" +
    "\n" +
    "  <div ng-if=\"template === 'installed'\" class=\"col-xs-6 text-right\">\n" +
    "\n" +
    "    <span ng-if=\"product.hasTrialExpired && buttonToShow !== 'update'\" class=\"trial_alert\">\n" +
    "        <span class=\"glyphicon glyphicon-alert\"\n" +
    "         popover-append-to-body=\"true\"\n" +
    "         popover-placement=\"bottom\"\n" +
    "         popover-trigger=\"mouseenter\"\n" +
    "         popover-title=\"Free trial has expired\"\n" +
    "         popover=\"Click the buy button to continue using this product{{(product.isIndefiniteTrial || product.isUniverse) ? ' without a watermarked export' : ''}}\">\n" +
    "        </span>\n" +
    "    </span>\n" +
    "\n" +
    "    <span ng-if=\"product.hasTrialExpired && buttonToShow === 'update'\" class=\"trial_alert\">\n" +
    "        <span class=\"glyphicon glyphicon-alert\"\n" +
    "         popover-append-to-body=\"true\"\n" +
    "         popover-placement=\"bottom\"\n" +
    "         popover-trigger=\"mouseenter\"\n" +
    "         popover-title=\"Free trial has expired\"\n" +
    "         popover=\"To continue using this product{{(product.isIndefiniteTrial || product.isUniverse) ? ' without a watermarked export' : ''}}, Update and then click the Buy button\">\n" +
    "        </span>\n" +
    "    </span>\n" +
    "\n" +
    "    <span ng-if=\"hasMoreInfo\" class=\"more_info\">\n" +
    "       <span class=\"glyphicon glyphicon-{{moreInfoIcon}}\"\n" +
    "        popover-append-to-body=\"true\"\n" +
    "        popover-placement=\"bottom\"\n" +
    "        popover-trigger=\"mouseenter\"\n" +
    "        popover-title=\"{{moreInfoTitle}}\"\n" +
    "        popover=\"{{moreInfoBody}}\"></span>\n" +
    "      <a ng-href=\"{{moreInfoURI}}\">{{moreInfoText}}</a>\n" +
    "    </span>\n" +
    "\n" +
    "    <a  ng-if=\"buttonToShow === 'update'\"\n" +
    "        class=\"btn btn-default btn-product btn-lg btn-primary\"\n" +
    "        href=\"{{product.updateURI}}\">Update</a>\n" +
    "\n" +
    "    <!-- also show universe uninstall button -->\n" +
    "    <a ng-if=\"(buttonToShow === 'download' && product.isUniverse && installationPane)\"\n" +
    "        class=\"btn btn-default btn-product btn-lg\" href=\"{{product.uninstallURI}}\">Uninstall</a>\n" +
    "\n" +
    "    <a  ng-if=\"buttonToShow === 'download'\"\n" +
    "        class=\"btn btn-default btn-download btn-lg btn-primary\"\n" +
    "        href=\"rg://download_universe?{{product.version}}\">Download Update</a>\n" +
    "\n" +
    "    <a ng-if=\"buttonToShow === 'buy'\"\n" +
    "       class=\"btn btn-default btn-product btn-lg\" href=\"{{product.buyURI}}\">Buy</a>\n" +
    "\n" +
    "      <!-- also show a universe uninstall button -->\n" +
    "    <a ng-if=\"buttonToShow === 'universe_buy' && installationPane\"\n" +
    "    class=\"btn btn-default btn-product btn-lg\" href=\"{{product.uninstallURI}}\">Uninstall</a>\n" +
    "\n" +
    "    <a ng-if=\"buttonToShow === 'universe_buy' && installationPane\"\n" +
    "        class=\"btn btn-default btn-product btn-lg btn-primary\" href=\"rg://buy_universe\">Buy</a>\n" +
    "\n" +
    "    <a ng-if=\"buttonToShow === 'universe_buy' && !installationPane\"\n" +
    "        class=\"btn btn-default btn-product btn-lg\" href=\"rg://buy_universe\">Buy</a>\n" +
    "\n" +
    "\n" +
    "    <a ng-if=\"buttonToShow === 'upgrade'\"\n" +
    "       class=\"btn btn-default btn-product btn-lg\" href=\"{{product.upgradeURI}}\">Upgrade</a>\n" +
    "\n" +
    "    <a ng-if=\"buttonToShow === 'uninstall'\"L\n" +
    "       class=\"btn btn-default btn-product btn-lg\" href=\"{{product.uninstallURI}}\">Uninstall</a>\n" +
    "\n" +
    "    <a  ng-if=\"(buttonToShow === 'install' && !product.isUniverse)\"\n" +
    "        class=\"btn btn-product btn-lg btn-primary\"\n" +
    "        href=\"{{product.installURI}}\">Install</a>\n" +
    "\n" +
    "    <a  ng-if=\"(buttonToShow === 'install' && product.isUniverse)\"\n" +
    "        class=\"btn btn-product btn-download btn-primary\"\n" +
    "        href=\"rg://download_universe\">Download Installer</a>\n" +
    "\n" +
    "    <div  ng-if=\"!(universe && installationPane) && buttonToShow === 'none' && upToDate\"\n" +
    "          class=\"status_text\">\n" +
    "      <span style=\"color: green; opacity: 0.5;\" class=\"glyphicon glyphicon-ok-sign\"></span>\n" +
    "      <span>Up to date</span>\n" +
    "    </div>\n" +
    "\n" +
    "\n" +
    "  </div>\n" +
    "\n" +
    "  <div ng-if=\"template === 'progress'\" class=\"col-xs-6\" style=\"text-align: right;\">\n" +
    "\n" +
    "    <div class=\"progressbar\">\n" +
    "      <span class=\"percent\">{{product.isIndeterminateProgress ? '&nbsp;' : product.progress + \"%\"}}</span>\n" +
    "      <progressbar ng-if=\"product.isIndeterminateProgress\" class=\"progress-striped active\" value=\"100\" animate=\"false\">\n" +
    "      </progressbar>\n" +
    "      <progressbar ng-if=\"!product.isIndeterminateProgress\" value=\"product.progress\" animate=\"false\">\n" +
    "      </progressbar>\n" +
    "      <a ng-href=\"{{product.cancelURI}}\"><span ng-show=\"product.cancelURI\" class=\"glyphicon glyphicon-remove-circle\"></span></a>\n" +
    "    </div>\n" +
    "    <div class=\"status\">\n" +
    "      {{product.progressText}}\n" +
    "    </div>\n" +
    "  </div>\n" +
    "\n" +
    "</div>\n"
  );


  $templateCache.put('/partials/_products.html',
    "<div ng-if=\"productsLoading\" class=\"container-fluid loading_indicator\">\n" +
    "  <div class=\"row\">\n" +
    "    <div class=\"col-xs-12 text-center\">\n" +
    "      <throbber size=\"50\"></throbber>\n" +
    "    </div>\n" +
    "  </div>\n" +
    "  <div class=\"row\">\n" +
    "    <div class=\"col-xs-12 text-center\"><h4>{{refreshThrobberText}}</h4></div>\n" +
    "  </div>\n" +
    "</div>\n" +
    "\n" +
    "<div ng-if=\"productsLoaded\" class=\"tab_content_container\" id=\"products\">\n" +
    "\n" +
    "  <div class=\"container-fluid\">\n" +
    "    <div class=\"row heading\">\n" +
    "      <div class=\"col-xs-9\">Installed</div>\n" +
    "      <div class=\"col-xs-3 text-right\">\n" +
    "        <a ng-show=\"(updatedProducts.length > 1)\" ng-click=\"updateAll()\" class=\"action_header\">Update All</a>&nbsp;\n" +
    "      </div>\n" +
    "    </div>\n" +
    "\n" +
    "    <product ng-repeat=\"product in installedProducts\" product=\"product\"></product>\n" +
    "\n" +
    "    <div class=\"row grey\" ng-show=\"installedProducts.length === 0\">\n" +
    "      <div class=\"col-xs-12\">\n" +
    "        <p>No Red Giant products detected.</p>\n" +
    "      </div>\n" +
    "    </div>\n" +
    "\n" +
    "  </div>\n" +
    "</div>\n"
  );


  $templateCache.put('/partials/_serial_number.html',
    "<div  class=\"serial_number_entry\" ng-mouseenter=\"$parent.serialHovered(true, $event)\"\n" +
    "      ng-mouseleave=\"$parent.serialHovered(false, $event)\"\n" +
    "      ng-hide=\"hide\"\n" +
    "      ><span class=\"number\"\n" +
    "        tooltip-placement=\"bottom\"\n" +
    "        tooltip=\"Press {{($parent.$parent.os === 'osx') ? '&#8984;' : 'Ctrl'}}-C to Copy\"\n" +
    "        >{{number}}</span><span ng-transclude></span>\n" +
    "      {{rolldownStates}}\n" +
    "    </div>\n"
  );


  $templateCache.put('/partials/_throbber.html',
    "<div class=\"throbber\" ng-style=\"throbbyStyle\">\n" +
    "  <div class=\"petal\"></div>\n" +
    "  <div class=\"petal\"></div>\n" +
    "  <div class=\"petal\"></div>\n" +
    "  <div class=\"petal\"></div>\n" +
    "  <div class=\"petal\"></div>\n" +
    "  <div class=\"petal\"></div>\n" +
    "  <div class=\"petal\"></div>\n" +
    "  <div class=\"petal\"></div>\n" +
    "</div>\n" +
    "\n"
  );


  $templateCache.put('/partials/_tool_gallery.html',
    "<div class=\"gallery\">\n" +
    "  <div ng-repeat=\"plugin in universePlugins()\" class=\"toolchip\"\n" +
    "      style=\"background-image: url('images/product-free-{{plugin.id}}-sml.jpg');\"\n" +
    "  >\n" +
    "    <aside ng-class=\"{not_hiding: (showingThumbnailInfoFor === plugin.id)}\">\n" +
    "      {{plugin.short_desc}}\n" +
    "    </aside>\n" +
    "    <article>\n" +
    "      <h1>{{plugin.name}}</h1>\n" +
    "    </article>\n" +
    "\n" +
    "    <footer>\n" +
    "      <span>Free</span>\n" +
    "      <span>\n" +
    "        <a  ng-mouseenter=\"showingThumbnailInfoFor = plugin.id\"\n" +
    "            ng-mouseleave=\"showingThumbnailInfoFor = -1\"\n" +
    "            >Learn More</a> | <a>Preview</a>\n" +
    "      </span>\n" +
    "    </footer>\n" +
    "  </div>\n" +
    "  <div style=\"clear: both;\"></div>\n" +
    "</div>\n"
  );


  $templateCache.put('/partials/_universe.html',
    "<div ng-if=\"!appReady\" class=\"container-fluid loading_indicator\">\n" +
    "  <div class=\"row\">\n" +
    "    <div class=\"col-xs-12 text-center\">\n" +
    "      <throbber size=\"50\"></throbber>\n" +
    "    </div>\n" +
    "  </div>\n" +
    "  <div class=\"row\">\n" +
    "    <div class=\"col-xs-12 text-center\"><h4>{{refreshThrobberText}}</h4></div>\n" +
    "  </div>\n" +
    "</div>\n" +
    "\n" +
    "<div ng-if=\"appReady\"  class=\"tab_content_container\" id=\"universe\">\n" +
    "  <div ng-if=\"universe.notOnDiskAtAll && !(loggedIn && isUniverseUser)\">\n" +
    "    <ng-include src=\"'/partials/_universe_not_installed_or_member.html'\"></ng-include>\n" +
    "  </div>\n" +
    "  <div ng-if=\"!universe.notOnDiskAtAll || (loggedIn && isUniverseUser)\">\n" +
    "    <div class=\"container-fluid\">\n" +
    "      <product installationPane=\"true\" product=\"universe\"></product>\n" +
    "    </div>\n" +
    "    <ng-include src=\"'/partials/_universe_membership_info_pane.html'\"></ng-include>\n" +
    "    <!--<ng-include src=\"'/partials/_universe_tools_pane.html'\"></ng-include>-->\n" +
    "  </div>\n" +
    "  <div class=\"scrolling_remainder\"></div>\n" +
    "</div>\n" +
    "\n" +
    "\n"
  );


  $templateCache.put('/partials/_universe_agreement_modal.html',
    "<div class=\"modal-header\">\n" +
    "  <button type=\"button\" class=\"close\" ng-click=\"cancel()\">×</button>\n" +
    "  <h3>Universe Agreement</h3>\n" +
    "</div>\n" +
    "<div class=\"modal-body\">\n" +
    "  <p>To install Red Giant Universe, you'll first need to agree to the End User License Agreement. Once you agree, you'll be able to start downloading the Universe library of effects and transitions, immediately.</p>\n" +
    "\n" +
    "  <div class=\"agreement\">\n" +
    "    <input style=\"margin-right: 0.5em;\" type=\"checkbox\" ng-model=\"agreeToUniverseTerms\" id=\"universeTerms\">\n" +
    "    <label for=\"universeTerms\">I agree to the <a ng-click=\"visitMothership('universe_eula')\">End User License Agreement</a></label>\n" +
    "  </div>\n" +
    "\n" +
    "</div>\n" +
    "<div class=\"modal-footer\">\n" +
    "  <button class=\"btn btn-default\" ng-click=\"$dismiss()\">Cancel</button>\n" +
    "  <button\n" +
    "    class=\"btn btn-primary\" ng-click=\"$close()\"\n" +
    "    ng-disabled=\"!agreeToUniverseTerms\">Ok</button>\n" +
    "</div>\n" +
    "\n"
  );


  $templateCache.put('/partials/_universe_conditions.html',
    "<div class=\"well legal\">\n" +
    "  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras et elementum nisl. Vestibulum pharetra, leo sodales ultrices interdum, nunc neque aliquam tortor, eu faucibus orci velit ut libero. Donec pulvinar, turpis id lacinia porta, elit magna convallis leo, sed sagittis massa sapien vel ligula. Quisque sit amet lectus vel dui bibendum consequat ut nec risus. Duis eu lobortis lectus, pharetra tincidunt diam. Quisque sit amet porttitor diam, sit amet porttitor arcu. Nulla quis gravida erat. Donec luctus nec lectus non porttitor. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Curabitur tempus id metus vel ultrices. Praesent vel sodales eros, id imperdiet leo. Sed eu magna quis tortor malesuada rhoncus. Etiam congue, magna ac pretium rutrum, urna turpis scelerisque nisl, id pharetra lectus justo ut ligula.</p>\n" +
    "\n" +
    "  <p>Donec placerat odio quis metus rutrum rutrum. Pellentesque eget neque nulla. Vestibulum fringilla ultricies elit sed tempus. In dignissim, risus in aliquet malesuada, libero odio lacinia lectus, in malesuada mauris sapien in lectus. Etiam cursus erat non convallis cursus. Integer ultrices nibh eget nibh suscipit, non laoreet purus condimentum. Nullam rhoncus ornare iaculis.</p>\n" +
    "\n" +
    "  <p>Integer tincidunt neque sed mauris dignissim, sit amet dignissim massa faucibus. Pellentesque semper risus vitae semper adipiscing. Aenean sollicitudin auctor laoreet. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Ut mattis egestas metus. Vivamus tincidunt nunc ut purus condimentum, non placerat nulla egestas. Pellentesque id lacinia quam, ut bibendum urna. Duis pretium luctus eleifend. Phasellus in tempus neque. Nam nec velit urna. Suspendisse pretium, justo a sodales luctus, purus velit bibendum nunc, eu rhoncus ante ipsum ullamcorper orci. Ut turpis ligula, tempus eu lacus et, iaculis dapibus nisi. Sed eu eros libero. In egestas mauris suscipit, porta ipsum non, ultricies ante. Phasellus vehicula imperdiet neque nec mattis. Mauris non blandit nunc, quis accumsan lectus.</p>\n" +
    "\n" +
    "  <p>Duis pellentesque arcu at elementum vestibulum. Praesent fringilla tristique orci, ac hendrerit nisi consectetur molestie. Aliquam vel nisl consectetur, gravida lorem malesuada, posuere libero. Maecenas justo turpis, pretium at lorem vel, euismod pretium arcu. Aliquam erat volutpat. Sed malesuada et justo sit amet ornare. Donec quis congue nisl. Sed feugiat, dolor vitae congue aliquet, nisi leo blandit ante, a suscipit magna magna vitae risus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis elit risus, lobortis euismod rutrum vel, aliquet nec justo. Nullam sit amet enim at urna volutpat posuere. Pellentesque eros metus, convallis eu sollicitudin non, adipiscing in lectus.</p>\n" +
    "\n" +
    "  <p>Duis gravida nibh dui, in imperdiet lacus suscipit rutrum. Etiam pretium gravida tellus, at scelerisque nisi mollis at. Phasellus non molestie tortor. Mauris urna eros, gravida eget adipiscing id, molestie vitae quam. Vestibulum feugiat arcu a tortor luctus vehicula ut vel mi. Fusce tempus elit nisi, ut mattis mi facilisis a. Maecenas ut fringilla nisi. Mauris sollicitudin justo sit amet accumsan congue. Mauris laoreet, lectus et feugiat congue, erat sapien vulputate mauris, et rutrum libero odio ac est.</p>\n" +
    "</div>\n"
  );


  $templateCache.put('/partials/_universe_host_apps.html',
    "<div class=\"modal-header\">\n" +
    "  <button type=\"button\" class=\"close\" ng-click=\"$close()\">×</button>\n" +
    "  <h3>Universe Host Applications</h3>\n" +
    "</div>\n" +
    "<div class=\"modal-body host-app-modal\">\n" +
    "\n" +
    "  <p>The Universe plugins are currently installed with the following host applications:</p>\n" +
    "  <ul ng-if=\"universe.hostAppsInstalled.length > 0\">\n" +
    "    <li ng-repeat=\"hostApp in universe.hostAppsInstalled\">{{hostApp.host}}</li>\n" +
    "  </ul>\n" +
    "\n" +
    "  <div ng-if=\"universe.hostAppsNotInstalled.length > 0\">\n" +
    "    <p>Other applications Universe supports include:</p>\n" +
    "    <ul>\n" +
    "      <li ng-repeat=\"hostApp in universe.hostAppsNotInstalled\">{{hostApp.host}}</li>\n" +
    "    </ul>\n" +
    "  </div>\n" +
    "</div>\n" +
    "\n" +
    "<div class=\"modal-footer\">\n" +
    "  <button autofocus class=\"btn btn-default\" ng-click=\"$close()\">OK</button>\n" +
    "</div>\n"
  );


  $templateCache.put('/partials/_universe_membership_info_pane.html',
    "<div class=\"container-fluid membership_info\">\n" +
    "\n" +
    "  <div class=\"row heading\">\n" +
    "    <div class=\"col-xs-12\" style=\"letter-spacing: 0.06em;\">Subscription</div>\n" +
    "  </div>\n" +
    "\n" +
    "  <!-- Membership Bar On Top: Paying -->\n" +
    "\n" +
    "  <div ng-if=\"isUniverseSubscriber\" class=\"row current_plan_bar\">\n" +
    "    <div ng-switch=\"universeTerm\" class=\"col-xs-6\">\n" +
    "      <h1 ng-switch-when=\"LIFETIME\">Lifetime Plan</h1>\n" +
    "      <h1 ng-switch-when=\"MONTHLY\">Monthly Plan</h1>\n" +
    "      <h1 ng-switch-when=\"ANNUAL\">Annual Plan</h1>\n" +
    "    </div>\n" +
    "    <div class=\"col-xs-6 membership_type\">\n" +
    "      <a class=\"btn btn-default pull-right\" ng-click=\"visitMothership('universe_account')\">\n" +
    "         Manage Your Subscription&hellip;\n" +
    "      </a>\n" +
    "    </div>\n" +
    "  </div>\n" +
    "\n" +
    "  <!-- Membership Bar On Top: Not-Paying -->\n" +
    "  <div ng-if=\"(isUniverseTrial || isUniverseExpired)\" class=\"row current_plan_bar\">\n" +
    "    <div class=\"col-xs-12\">\n" +
    "      <h3 ng-if=\"isUniverseTrial\">Trial</h3>\n" +
    "      <h3 ng-if=\"(isUniverseExpired && isUniverseInstalled && loggedIn)\" class=\"trial_expired_heading\">Trial Expired</h3>\n" +
    "    </div>\n" +
    "  </div>\n" +
    "\n" +
    "  <!-- Not logged in -->\n" +
    "  <div ng-if=\"!loggedIn\" class=\"row current_plan_bar\">\n" +
    "    <div class=\"col-xs-8\">\n" +
    "      <p style=\"line-height: 35px;\">Please sign in to review your Universe subscription</p>\n" +
    "    </div>\n" +
    "    <div class=\"col-xs-4 text-right\">\n" +
    "      <a class=\"btn btn-primary btn-product btn-lg\" ng-click=\"showLogin(false, false)\">\n" +
    "        Sign In\n" +
    "      </a>\n" +
    "    </div>\n" +
    "  </div>\n" +
    "\n" +
    "  <!-- Not-paying universe content meat (a blurb and a video) -->\n" +
    "  <div ng-if=\"(isUniverseTrial || isUniverseExpired)\" class=\"row\">\n" +
    "\n" +
    "\n" +
    "    <div class=\"col-xs-7\">\n" +
    "      <p class=\"time_heading\" ng-if=\"(isUniverseExpired) || (isUniverseExpired && isUniverseInstalled)  \">\n" +
    "        Subscription Expired\n" +
    "      </p>\n" +
    "      <p class=\"time_heading\" ng-if=\"isUniverseTrial\">\n" +
    "        Subscription Expires: <span class='trial_expiry_value'>{{universeTermDaysLeft}} Day{{ (universeTermDaysLeft !== 1) ? 's' : ''}} Remaining</span>\n" +
    "      </p>\n" +
    "      <p ng-if=\"isUniverseExpired\">\n" +
    "        Just $199 a year gives you access to Universe, our video transition and effects plugins for editors and motion graphics artists.\n" +
    "      </p>\n" +
    "\n" +
    "      <p ng-if=\"isUniverseTrial\">\n" +
    "        Activate your subscription so you don't lose access to Universe's full library of GPU-accelerated plugins.\n" +
    "      </p>\n" +
    "\n" +
    "      <div class=\"pricing_link\" ng-click=\"visitMothership('pricing');\">See all pricing options</div>\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"col-xs-5 text-right\" style=\"margin-top: 30px; margin-bottom: 20px;\">\n" +
    "      <div class=\"video_frame upgrade\" ng-click=\"displayVideo('upgradeUniverse');\"><div><i class=\"big play\"></i></div></div>\n" +
    "    </div>\n" +
    "  </div>\n" +
    "\n" +
    "  <!--========================================\n" +
    "  =            Universe Paid                 =\n" +
    "  ==========================================-->\n" +
    "  <div class=\"row\" ng-show=\"isUniverseSubscriber\">\n" +
    "    <div class=\"col-xs-12\">\n" +
    "      <p class=\"time_heading\" ng-show=\"universeTerm !== 'LIFETIME' && universeAutorenews\" >\n" +
    "        Subscription Renews: {{ universeAutorenews | date:'MM/dd/yyyy'}}\n" +
    "      </p>\n" +
    "      <p class=\"time_heading\" ng-show=\"universeExpirationDate && universeTerm !== 'LIFETIME' && !universeAutorenews\">\n" +
    "        Subscription Expires: <span class='trial_expiry_value'>{{ universeExpirationDate | date:'MM/dd/yyyy'}}</span>\n" +
    "      </p>\n" +
    "      <p ng-if=\"isUniverseOneXInstalled && isUniverseEarlyAdopter && isFCPXInstalled\">\n" +
    "        <strong>NOTE FOR FINAL CUT PRO X:</strong> Some Universe plugins may fail to apply when loading old projects. For a workaround and more info, please see this <a ng-click=\"visitMothership('fcpx_universe_faq');\">FAQ</a>.\n" +
    "      </p>\n" +
    "    </div>\n" +
    "  </div>\n" +
    "\n" +
    "  <div class=\"row extended_info\" ng-show=\"universe.isInstalled\" collapse=\"!planInfoDisplayed\">\n" +
    "    <div class=\"col-xs-7\">\n" +
    "      <h2>Premium Membership</h2>\n" +
    "      <p>A Premium membership gives you access to even more tools. Start with 19 additional transitions and effects, with more Premium tools added frequently. Premium membership is available in monthly or annual subscription.</p>\n" +
    "    </div>\n" +
    "    <div class=\"col-xs-5\">\n" +
    "      <h2>&nbsp;</h2>\n" +
    "      <div class=\"premium_shoppe container-fluid\">\n" +
    "        <div class=\"row\">\n" +
    "          <div class=\"col-xs-6\">Monthly</div>\n" +
    "          <div class=\"col-xs-6\">$20 USD</div>\n" +
    "        </div>\n" +
    "        <div class=\"row\">\n" +
    "          <div class=\"col-xs-7\" style=\"padding-right: 0px;\">Annual <em>(20% savings)</em></div>\n" +
    "          <div class=\"col-xs-5\">$199 USD</div>\n" +
    "        </div>\n" +
    "      </div>\n" +
    "    </div>\n" +
    "  </div>\n" +
    "</div>\n"
  );


  $templateCache.put('/partials/_universe_not_installed_or_member.html',
    "<div class=\"container-fluid description_area\">\n" +
    "  <div class=\"row\">\n" +
    "    <div class=\"col-xs-12\">\n" +
    "      <h2>Tools for Editors and Motion Graphic Artists</h2>\n" +
    "    </div>\n" +
    "  </div>\n" +
    "  <div class=\"row grey universe_signup\">\n" +
    "    <div class=\"col-xs-7\">\n" +
    "      <h3>Introducing Red Giant Universe, GPU-accelerated effects and transitions for editors and motion graphic artists.</h3>\n" +
    "      <p>Give your footage authentic retro and modern day looks. Create beautiful looping backgrounds and motion graphics elements. Build fast, unique transitions with little or no work. Universe includes essential effects and tools that give you better results with more shortcuts, options and control than anything in your host application.</p>\n" +
    "      <div style=\"margin: 20px 0 15px 0;\">\n" +
    "          <button ng-if=\"!loggedIn\"\n" +
    "                  class=\"btn btn-sm btn-primary\"\n" +
    "                  style=\"padding-left: 2em; padding-right: 2em;\"\n" +
    "                  ng-click=\"showLogin(true, true)\">\n" +
    "                  Download Universe</button>\n" +
    "          <a ng-if=\"loggedIn && isUniverseUser\"\n" +
    "                  class=\"btn btn-sm btn-primary\"\n" +
    "                  style=\"padding-left: 2em; padding-right: 2em;\"\n" +
    "                  ng-href=\"rg://download_universe\">\n" +
    "                  Download Universe</a>\n" +
    "          <button ng-if=\"loggedIn && !isUniverseUser\"\n" +
    "                  class=\"btn btn-sm btn-primary\"\n" +
    "                  style=\"padding-left: 2em; padding-right: 2em;\"\n" +
    "                  ng-click=\"signUpUniverse()\">\n" +
    "                  Download Universe</button>\n" +
    "    </div>\n" +
    "</div>\n" +
    "\n" +
    "    <div class=\"col-xs-5 text-center\">\n" +
    "      <div class=\"video_frame register\" style=\"margin-top: 8px;\" ng-click=\"displayVideo('tryUniverse');\"><div><i class=\"big play\"></i></div></div>\n" +
    "    </div>\n" +
    "  </div>\n" +
    "  <div class=\"row grey\">\n" +
    "    <div class=\"col-xs-7\">\n" +
    "    </div>\n" +
    "    <div class=\"col-xs-5 text-center\">\n" +
    "\n" +
    "    </div>\n" +
    "  </div>\n" +
    "</div>\n"
  );


  $templateCache.put('/partials/_universe_tools_pane.html',
    "<div ng-if=\"universe.isInstalled\" class=\"container-fluid description_area\">\n" +
    "  <div class=\"row heading\">\n" +
    "    <div class=\"col-xs-12\">\n" +
    "     <span ng-click=\"viewStates.toolPaneDisplayed = !viewStates.toolPaneDisplayed\" class=\"disclosure\">\n" +
    "        <span  ng-class=\"{'flydown-closed': !viewStates.toolPaneDisplayed, 'flydown-open': viewStates.toolPaneDisplayed}\" style=\"margin: 0.5em;\"></span>\n" +
    "     </span>\n" +
    "     <span ng-click=\"viewStates.toolPaneDisplayed = !viewStates.toolPaneDisplayed\">Your Tools</span>\n" +
    "      <div class=\"dropdown\">\n" +
    "        <button class=\"btn btn-xs btn-link dropdown-toggle uni-tools-bar\">\n" +
    "          <span style=\"color: black; margin-left: 10px; margin-bottom: 4px;\" class=\"glyphicon glyphicon-cog\"></span><span class=\"caret\"></span>\n" +
    "        </button>\n" +
    "        <ul class=\"dropdown-menu\">\n" +
    "          <!--\n" +
    "          <li><a ng-class=\"{disabled: (!universe.isInstalled || universe.isInstalling)}\" ng-href=\"{{ (universe.isInstalled ? 'rg://reinstall_universe' : '') }}\">Reinstall</a></li>\n" +
    "          <li><a ng-class=\"{disabled: (!universe.isInstalled || universe.isInstalling)}\" ng-href=\"{{ (universe.isInstalled ? 'rg://uninstall_all_universe' : '') }}\">Uninstall</a></li>\n" +
    "          -->\n" +
    "          <li><a ng-class=\"{disabled: (!universe.isInstalled || universe.isInstalling)}\" ng-click=\"universeHostAppsModal()\">Universe Host Applications&hellip;</a></li>\n" +
    "          <!--\n" +
    "          <li ng-if=\"isUniverseEarlyAdopter && universeLegacyTools.isInstalled && !isUniverseOneXInstalled\">\n" +
    "            <a ng-class=\"{disabled: (!universe.isInstalled || universe.isInstalling)}\"ng-href=\"{{universeLegacyTools.uninstallURI}}\">Uninstall Legacy Tools</a>\n" +
    "          </li>\n" +
    "          <li ng-if=\"isUniverseEarlyAdopter && !universeLegacyTools.isInstalled && !isUniverseOneXInstalled\">\n" +
    "            <a ng-class=\"{disabled: (!universe.isInstalled || universe.isInstalling)}\"ng-href=\"{{universeLegacyTools.installURI}}\">Install Legacy Tools</a>\n" +
    "          </li>\n" +
    "        -->\n" +
    "        </ul>\n" +
    "      </div>\n" +
    "      <span ng-show=\"universeLegacyTools.isUninstalling\">Uninstalling Legacy Tools ...</span>\n" +
    "      <span ng-show=\"universeLegacyTools.isInstalling\">Installing Legacy Tools ({{universeLegacyTools.progress}}%)...</span>\n" +
    "    </div>\n" +
    "  </div>\n" +
    "  <div collapse=\"!viewStates.toolPaneDisplayed\">\n" +
    "    <h3 ng-if=\"isUniverseOneXInstalled\">Premium Tools</h3>\n" +
    "    <pluginlist visible=\"true\" plugins=\"(!isUniverseOneXInstalled ? plugins.universe : plugins.premium)\"></pluginlist>\n" +
    "    <h3 ng-if=\"isUniverseOneXInstalled\">Free Tools</h3>\n" +
    "    <pluginlist ng-if=\"isUniverseOneXInstalled\" visible=\"true\" plugins=\"plugins.free\"></pluginlist>\n" +
    "    <div ng-if=\"isUniverseEarlyAdopter && !isUniverseOneXInstalled\" class=\"row\" ng-click=\"viewStates.legacyToolsDisplayed = !viewStates.legacyToolsDisplayed\">\n" +
    "      <div class=\"col-xs-12\" style=\"border-top: 1px solid #eee;\">\n" +
    "        <span ng-class=\"{'flydown-closed': !viewStates.legacyToolsDisplayed, 'flydown-open': viewStates.legacyToolsDisplayed}\" style=\"margin-right: 0.5em\"></span>\n" +
    "        Legacy Tools {{universeLegacyTools.isInstalled ? '' : '(Not Installed)'}}\n" +
    "      </div>\n" +
    "    </div>\n" +
    "    <pluginlist visible=\"viewStates.legacyToolsDisplayed\"\n" +
    "                plugins=\"(!isUniverseOneXInstalled ? plugins.legacy : plugins.free)\"></pluginlist>\n" +
    "  </div>\n" +
    "</div>\n"
  );


  $templateCache.put('/partials/_video_modal.html',
    "<div class=\"modal-body\">\n" +
    "  <div>\n" +
    "    <iframe\n" +
    "      src=\"http://player.vimeo.com/video/87001310?autoplay=1\"\n" +
    "      frameborder=\"0\"></iframe>\n" +
    "  </div>\n" +
    "</div>\n" +
    "\n"
  );

}]);

angular.module('linkApp').run(['$templateCache', function($templateCache) {
  'use strict';

  $templateCache.put("template/modal/backdrop.html",
    "<div class=\"modal-backdrop fade\"\n" +
    "     ng-class=\"{in: animate}\"\n" +
    "     ng-style=\"{'z-index': 1040 + (index && 1 || 0) + index*10}\"\n" +
    "></div>");

  $templateCache.put("template/modal/window.html",
    "<div tabindex=\"-1\" role=\"dialog\" class=\"modal fade\" ng-class=\"{in: animate}\" ng-style=\"{'z-index': 1050 + index*10, display: 'block'}\" ng-click=\"close($event)\">\n" +
    "    <div class=\"modal-dialog\" ng-class=\"{'modal-sm': size == 'sm', 'modal-lg': size == 'lg'}\"><div class=\"modal-content\" ng-transclude></div></div>\n" +
    "</div>");

  $templateCache.put('template/progressbar/progressbar.html',
    "<div class=\"progress\"><div class=\"progress-bar\" ng-class=\"type && 'progress-bar-' + type\" " +
    "role=\"progressbar\" aria-valuenow=\"{{value}}\" aria-valuemin=\"0\" aria-valuemax=\"{{max}}\" " +
    "ng-style=\"{width: percent + '%'}\" aria-valuetext=\"{{percent | number:0}}%\" ng-transclude></div></div>");

  $templateCache.put('template/progressbar/bar.html',
    "<div class=\"progress-bar\" ng-class=\"type && 'progress-bar-' + type\" " +
    "role=\"progressbar\" aria-valuenow=\"{{value}}\" aria-valuemin=\"0\" " +
    "aria-valuemax=\"{{max}}\" ng-style=\"{width: percent + '%'}\" " +
    "aria-valuetext=\"{{percent | number:0}}%\" ng-transclude></div>");

  $templateCache.put('template/progressbar/progress.html',
    "<div class=\"progress\" ng-transclude></div>");

  $templateCache.put('template/accordion/accordion-group.html',
    "<div class=\"panel panel-default\">" +
    "  <div class=\"panel-heading\">" +
    "    <h4 class=\"panel-title\">" +
    "      <a class=\"accordion-toggle\" ng-click=\"toggleOpen()\" accordion-transclude=\"heading\"><span ng-class=\"{'text-muted': isDisabled}\">{{heading}}</span></a>" +
    "    </h4>" +
    "  </div>" +
    "  <div class=\"panel-collapse\" collapse=\"!isOpen\">" +
    "    <div class=\"panel-body\" ng-transclude></div>" +
    "  </div>" +
    "</div>");

  $templateCache.put('template/accordion/accordion.html',
    "<div class=\"panel-group\" ng-transclude></div>");

  $templateCache.put('template/popover/popover.html',
    "<div class=\"popover {{placement}}\" ng-class=\"{ in: isOpen(), fade: animation() }\">" +
    "  <div class=\"arrow\"></div>" +
    "  <div class=\"popover-inner\">" +
    "      <h3 class=\"popover-title\" ng-bind=\"title\" ng-show=\"title\"></h3>" +
    "      <div class=\"popover-content\" ng-bind-html=\"content\"></div>" +
    "  </div>" +
    "</div>");

  $templateCache.put('template/tooltip/tooltip-popup.html',
    "<div class=\"tooltip {{placement}} {{popupClass}}\" ng-class=\"{ in: isOpen(), fade: animation() }\">" +
    "  <div class=\"tooltip-arrow\"></div>" +
    "  <div class=\"tooltip-inner\" bind-html-unsafe=\"content\"></div>" +
    "</div>");
}]);
